import fs from "fs";
import path from "path";
import crypto from "crypto";

const DB_PATH = path.resolve(process.cwd(), "db.json");
const ENCRYPTION_KEY = process.env.DB_ENCRYPTION_KEY || "integram-super-secret-key-32bytes-long!"; // Must be 32 bytes
const IV_LENGTH = 16; // For AES-256-CBC

// Encrypt string helper
export function encrypt(text: string): string {
  try {
    const iv = crypto.randomBytes(IV_LENGTH);
    const key = crypto.createHash("sha256").update(ENCRYPTION_KEY).digest();
    const cipher = crypto.createCipheriv("aes-256-cbc", key, iv);
    let encrypted = cipher.update(text, "utf8", "hex");
    encrypted += cipher.final("hex");
    return iv.toString("hex") + ":" + encrypted;
  } catch (err) {
    console.error("Encryption error:", err);
    return text; // Fallback
  }
}

// Decrypt string helper
export function decrypt(text: string): string {
  try {
    const textParts = text.split(":");
    const ivHex = textParts.shift();
    if (!ivHex) return text;
    const iv = Buffer.from(ivHex, "hex");
    const encryptedText = textParts.join(":");
    const key = crypto.createHash("sha256").update(ENCRYPTION_KEY).digest();
    const decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
    let decrypted = decipher.update(encryptedText, "hex", "utf8");
    decrypted += decipher.final("utf8");
    return decrypted;
  } catch (err) {
    console.error("Decryption error:", err);
    return text; // Fallback
  }
}

export interface User {
  id: string;
  email: string;
  name: string;
  avatar: string;
  provider: "google" | "yandex" | "telegram" | "vk";
  createdAt: string;
}

export interface SavedSpreadsheet {
  id: string;
  userId: string;
  name: string;
  columns: string[];
  rows: string[][]; // Encrypted
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId?: string;
  action: string;
  payloadSize: number;
  durationMs: number;
  optimizationNotes: string;
}

export interface DatabaseSchema {
  users: User[];
  spreadsheets: SavedSpreadsheet[];
  logs: AuditLog[];
}

const defaultDB: DatabaseSchema = {
  users: [],
  spreadsheets: [],
  logs: []
};

// Read database
export function readDB(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_PATH)) {
      writeDB(defaultDB);
      return defaultDB;
    }
    const data = fs.readFileSync(DB_PATH, "utf8");
    return JSON.parse(data);
  } catch (err) {
    console.error("Failed to read database file:", err);
    return defaultDB;
  }
}

// Write database atomically
export function writeDB(db: DatabaseSchema): void {
  try {
    const tempPath = `${DB_PATH}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(db, null, 2), "utf8");
    fs.renameSync(tempPath, DB_PATH);
  } catch (err) {
    console.error("Failed to write database file:", err);
  }
}

// Database helper operations
export const dbOperations = {
  // Authentication & Users
  getOrCreateUser: (user: Omit<User, "id" | "createdAt">): User => {
    const db = readDB();
    let existingUser = db.users.find(u => u.email === user.email && u.provider === user.provider);
    
    if (!existingUser) {
      existingUser = {
        ...user,
        id: "usr_" + crypto.randomUUID().replace(/-/g, "").slice(0, 12),
        createdAt: new Date().toISOString()
      };
      db.users.push(existingUser);
      writeDB(db);
    }
    return existingUser;
  },

  getUserById: (id: string): User | undefined => {
    const db = readDB();
    return db.users.find(u => u.id === id);
  },

  // Spreadsheets
  saveSpreadsheet: (userId: string, name: string, columns: string[], rows: string[][]): SavedSpreadsheet => {
    const db = readDB();
    
    // Encrypt rows
    const serializedRows = JSON.stringify(rows);
    const encryptedRowsString = encrypt(serializedRows);

    // Check if table with this name already exists for this user, if so update it
    const existingIdx = db.spreadsheets.findIndex(s => s.userId === userId && s.name === name);
    
    let saved: SavedSpreadsheet;
    
    if (existingIdx >= 0) {
      db.spreadsheets[existingIdx] = {
        ...db.spreadsheets[existingIdx],
        columns,
        rows: [[encryptedRowsString]], // Wrapper for database storage
        updatedAt: new Date().toISOString()
      };
      saved = db.spreadsheets[existingIdx];
    } else {
      saved = {
        id: "sheet_" + crypto.randomUUID().replace(/-/g, "").slice(0, 12),
        userId,
        name,
        columns,
        rows: [[encryptedRowsString]],
        updatedAt: new Date().toISOString()
      };
      db.spreadsheets.push(saved);
    }
    
    writeDB(db);
    return saved;
  },

  getSpreadsheetsByUser: (userId: string) => {
    const db = readDB();
    const userSheets = db.spreadsheets.filter(s => s.userId === userId);
    
    // Decrypt on retrieval
    return userSheets.map(s => {
      try {
        const encryptedStr = s.rows[0]?.[0];
        if (encryptedStr) {
          const decryptedStr = decrypt(encryptedStr);
          const decryptedRows = JSON.parse(decryptedStr);
          return {
            ...s,
            rows: decryptedRows as string[][]
          };
        }
      } catch (err) {
        console.error("Failed to decrypt spreadsheet rows:", err);
      }
      return {
        ...s,
        rows: [] as string[][]
      };
    });
  },

  // Audit Logs
  logEvent: (action: string, userId?: string, payloadSize = 0, durationMs = 0, optimizationNotes = "None"): AuditLog => {
    const db = readDB();
    const logEntry: AuditLog = {
      id: "log_" + crypto.randomUUID().replace(/-/g, "").slice(0, 12),
      timestamp: new Date().toISOString(),
      userId,
      action,
      payloadSize,
      durationMs,
      optimizationNotes
    };
    
    db.logs.push(logEntry);
    
    // Cap log entries at 500 to optimize memory/file size
    if (db.logs.length > 500) {
      db.logs.shift();
    }
    
    writeDB(db);
    return logEntry;
  },

  getLogs: (limit = 50): AuditLog[] => {
    const db = readDB();
    return db.logs.slice(-limit).reverse();
  }
};
