export interface SEOArticle {
  id: string;
  title: string;
  slug: string;
  category: "basic" | "formulas" | "automation" | "tables";
  summary: string;
  content: string; // Full Russian explanation, ~700-1000 chars, SEO optimized
  exampleData?: {
    columns: string[];
    rows: string[][];
  };
  keywords: string[];
  crossLinks: { text: string; slug: string }[];
}

export interface CellStyle {
  bold?: boolean;
  italic?: boolean;
  align?: "left" | "center" | "right";
  bg?: string; // Tailwind color class or hex
  color?: string; // Tailwind color class or hex
}

export interface SheetCell {
  value: string; // raw input (e.g. "10" or "=SUM(A1:A5)" or "Text")
  computed?: string; // computed formula output
  style?: CellStyle;
}

export interface SheetState {
  columns: string[]; // ["A", "B", "C", ...]
  rows: SheetCell[][]; // grid of cells
  activeCell: { r: number; c: number } | null;
}

export interface SyncDevice {
  id: string;
  name: string;
  type: "mobile" | "desktop" | "tablet";
  lastSync: string;
  isCurrent: boolean;
}

export interface UserSession {
  isLoggedIn: boolean;
  userId?: string;
  name?: string;
  email?: string;
  avatar?: string;
  provider?: "google" | "yandex" | "telegram" | "vk";
}
