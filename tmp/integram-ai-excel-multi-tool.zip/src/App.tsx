import React, { useState, useEffect } from "react";
import { 
  Sparkles, 
  Table, 
  FolderSync, 
  BookOpen, 
  Database, 
  HelpCircle,
  TrendingUp,
  User,
  Activity,
  Wand2,
  Lock,
  Smartphone,
  Send,
  MessageCircle,
  LogOut,
  ArrowRight,
  Bot,
  Globe,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Spreadsheet from "./components/Spreadsheet";
import Converters from "./components/Converters";
import SEOContent from "./components/SEOContent";
import AuthSync from "./components/AuthSync";
import IntegramBanner from "./components/IntegramBanner";
import IntegramBuilder from "./components/IntegramBuilder";
import { UserSession } from "./types";

export default function App() {
  const [activeTab, setActiveTab] = useState<"spreadsheet" | "converters" | "builder" | "seo" | "sync">("spreadsheet");
  
  // State for passing data to Integram Builder
  const [builderColumns, setBuilderColumns] = useState<string[]>([]);
  const [builderRows, setBuilderRows] = useState<string[][]>([]);

  // Shared state to allow loading tables from OCR or SEO articles into the active Spreadsheet
  const [spreadsheetOverride, setSpreadsheetOverride] = useState<{ columns: string[]; rows: string[][] } | null>(null);

  // Authorization state
  const [session, setSession] = useState<UserSession>({
    isLoggedIn: false
  });

  // Floating Telegram Chat State
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<Array<{ sender: "user" | "bot"; text: string; time: string }>>([
    {
      sender: "bot",
      text: "Привет! Я официальный ИИ-ассистент @Integrammbot от команды Интеграм АИ. 🤖\n\nЯ помогу вам разобраться с формулами Excel (ВПР, СУММЕСЛИ, ИНДЕКС) или расскажу, как автоматически превратить ваши таблицы в полноценное CRM-приложение, базу данных или веб-интерфейс без программирования всего за 45 минут!\n\nО чем бы вы хотели узнать?",
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [chatInput, setChatInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [showAuthDropdown, setShowAuthDropdown] = useState(false);

  const handleLoadDataIntoSpreadsheet = (data: { columns: string[]; rows: string[][] }) => {
    setSpreadsheetOverride(data);
    setActiveTab("spreadsheet");
  };

  // Secure real login that synchronizes with our newly created Express database layer
  const handleLoginBackend = async (email: string, name: string, avatar: string, provider: "google" | "yandex" | "telegram" | "vk") => {
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, name, avatar, provider })
      });
      const data = await res.json();
      if (data.success) {
        setSession({
          isLoggedIn: true,
          userId: data.user.id,
          name: data.user.name,
          email: data.user.email,
          avatar: data.user.avatar,
          provider: data.user.provider
        });
        
        // Push a Telegram welcome message if they authorized via Telegram
        if (provider === "telegram") {
          setChatMessages(prev => [
            ...prev,
            {
              sender: "bot",
              text: `✨ Вы успешно авторизовались через Telegram! Теперь вы можете отправлять мне свои запросы на формулы или архитектуру приложений прямо из этого веб-интерфейса!`,
              time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            }
          ]);
          setIsChatOpen(true);
        }
      }
    } catch (err) {
      console.error("Backend login error, falling back to local simulation:", err);
      // Fallback in case of server delay
      setSession({
        isLoggedIn: true,
        name,
        email,
        avatar,
        provider
      });
    }
    setShowAuthDropdown(false);
  };

  const handleLogout = () => {
    setSession({ isLoggedIn: false });
    setShowAuthDropdown(false);
  };

  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userText = chatInput.trim();
    const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // Add User message
    setChatMessages(prev => [...prev, { sender: "user", text: userText, time: currentTime }]);
    setChatInput("");
    setIsTyping(true);

    try {
      const response = await fetch("/api/bot/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          message: userText,
          userId: session.userId || "guest"
        })
      });
      const data = await response.json();
      
      setTimeout(() => {
        setChatMessages(prev => [
          ...prev, 
          { 
            sender: "bot", 
            text: data.reply || "Извините, не удалось соединиться с ИИ-моделью.", 
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
          }
        ]);
        setIsTyping(false);
      }, 600);

    } catch (err) {
      console.error("Failed to fetch bot response:", err);
      setTimeout(() => {
        setChatMessages(prev => [
          ...prev, 
          { 
            sender: "bot", 
            text: "⚠️ Произошла сетевая ошибка при общении с ботом. Пожалуйста, попробуйте еще раз.", 
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
          }
        ]);
        setIsTyping(false);
      }, 600);
    }
  };

  const tabs = [
    { id: "spreadsheet", label: "Редактор Таблиц", icon: Table, desc: "Аналог Google Таблиц" },
    { id: "converters", label: "ИИ и Конвертеры", icon: FolderSync, desc: "PDF в Excel, OCR по фото" },
    { id: "builder", label: "ИИ Конструктор", icon: Wand2, desc: "Создание приложений Integram" },
    { id: "seo", label: "База знаний", icon: BookOpen, desc: "Инструкции и формулы Excel" },
    { id: "sync", label: "Синхронизация и ЛК", icon: Database, desc: "Связь между устройствами" }
  ];

  return (
    <div className="min-h-screen bg-slate-50/50 text-slate-800 antialiased font-sans">
      
      {/* Top Announcement Bar */}
      <div className="bg-indigo-600 text-white py-2 px-4 text-center text-[11px] md:text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm">
        <Sparkles className="w-3.5 h-3.5 text-indigo-200 animate-pulse" />
        <span>Интеграм АИ - из Excel в веб-приложение за 45 минут!</span>
        <a
          href="https://ideav.ru/excel-to-app.html"
          target="_blank"
          rel="noopener noreferrer"
          className="underline hover:text-indigo-100 font-bold ml-1 cursor-pointer"
        >
          Начать конструировать сейчас
        </a>
      </div>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 py-6 md:py-8 space-y-6 md:space-y-8">
        
        {/* Navigation / Header with integrated right-top Authorization block */}
        <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-linear-to-tr from-indigo-500 to-indigo-600 text-white rounded-xl shadow-md shadow-indigo-100 flex items-center justify-center">
              <Wand2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-slate-900 text-lg md:text-xl tracking-tight">
                  Интеграм АИ
                </h1>
                <span className="text-[10px] bg-indigo-50 text-indigo-700 font-bold px-2 py-0.5 rounded-full border border-indigo-100 flex items-center gap-1">
                  🪄 Магистр магии Excel-автоматизации
                </span>
              </div>
              <p className="text-xs text-slate-500 max-w-lg font-medium leading-relaxed mt-0.5">
                Интеллектуальная среда для работы с таблицами: автоматическое создание no-code приложений, OCR-распознавание, конвертеры и база знаний формул.
              </p>
            </div>
          </div>

          {/* Top Right Authorization / Session Block */}
          <div className="relative flex items-center gap-3 border-t md:border-t-0 md:border-l border-slate-100 pt-3 md:pt-0 md:pl-6">
            {!session.isLoggedIn ? (
              <div className="flex flex-col items-end gap-1.5 w-full md:w-auto">
                <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Войти в личный кабинет:</span>
                <div className="flex flex-wrap gap-1.5">
                  <button 
                    onClick={() => handleLoginBackend("google.user@gmail.com", "Google Пользователь", "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&q=80&w=100", "google")}
                    className="flex items-center justify-center gap-1 bg-red-50 text-red-600 hover:bg-red-100 px-2.5 py-1.5 rounded-lg text-[11px] font-bold border border-red-200/50 transition-colors cursor-pointer"
                  >
                    Google
                  </button>
                  <button 
                    onClick={() => handleLoginBackend("yandex.user@yandex.ru", "Яндекс Пользователь", "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100", "yandex")}
                    className="flex items-center justify-center gap-1 bg-amber-50 text-amber-700 hover:bg-amber-100 px-2.5 py-1.5 rounded-lg text-[11px] font-bold border border-amber-200/50 transition-colors cursor-pointer"
                  >
                    Яндекс
                  </button>
                  <button 
                    onClick={() => handleLoginBackend("telegram.user@t.me", "Телеграм Пользователь", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100", "telegram")}
                    className="flex items-center justify-center gap-1 bg-sky-50 text-sky-600 hover:bg-sky-100 px-2.5 py-1.5 rounded-lg text-[11px] font-bold border border-sky-200/50 transition-colors cursor-pointer"
                  >
                    Telegram
                  </button>
                  <button 
                    onClick={() => handleLoginBackend("vk.user@vk.com", "ВК Пользователь", "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100", "vk")}
                    className="flex items-center justify-center gap-1 bg-blue-50 text-blue-600 hover:bg-blue-100 px-2.5 py-1.5 rounded-lg text-[11px] font-bold border border-blue-200/50 transition-colors cursor-pointer"
                  >
                    ВКонтакте
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <img 
                  src={session.avatar} 
                  alt="Avatar" 
                  className="w-10 h-10 rounded-full border-2 border-indigo-200 object-cover shadow-sm" 
                />
                <div className="text-left">
                  <div className="flex items-center gap-1.5">
                    <p className="font-extrabold text-slate-800 text-xs truncate max-w-[150px]">{session.name}</p>
                    <span className="text-[8px] uppercase font-bold bg-indigo-100 text-indigo-700 px-1 rounded border border-indigo-200">
                      {session.provider}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                      Синхронизирован
                    </span>
                    <button 
                      onClick={handleLogout}
                      className="text-[10px] text-slate-400 hover:text-red-500 font-bold underline transition-colors cursor-pointer"
                    >
                      Выйти
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </header>

        {/* Tab switcher buttons */}
        <nav className="grid grid-cols-5 gap-1 md:gap-2 bg-slate-100 p-1 md:p-1.5 rounded-xl md:rounded-2xl border border-slate-200/50">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex flex-col md:flex-row items-center gap-1 md:gap-2 p-1.5 md:p-2.5 rounded-lg md:rounded-xl text-center md:text-left cursor-pointer transition-all min-w-0 ${activeTab === tab.id ? "bg-white text-indigo-600 shadow-xs" : "text-slate-500 hover:text-slate-800 hover:bg-white/40"}`}
            >
              <div className={`p-1 md:p-1.5 rounded-md md:rounded-lg shrink-0 ${activeTab === tab.id ? "bg-indigo-50 text-indigo-600" : "bg-transparent text-slate-400"}`}>
                <tab.icon className="w-3.5 h-3.5 md:w-4 md:h-4" />
              </div>
              <div className="min-w-0 w-full text-center md:text-left">
                <p className="text-[9px] sm:text-[10px] md:text-xs font-bold leading-tight truncate">{tab.label}</p>
                <span className="text-[9px] text-slate-400 leading-none hidden lg:inline-block truncate max-w-full">{tab.desc}</span>
              </div>
            </button>
          ))}
        </nav>

        {/* Dynamic Workspace / Active Views */}
        <main className="min-h-[460px]">
          <AnimatePresence mode="wait">
            {activeTab === "spreadsheet" && (
              <motion.div
                key="spreadsheet"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18 }}
              >
                <Spreadsheet 
                  onLoadIntegram={(cols, rows) => {
                    setBuilderColumns(cols);
                    setBuilderRows(rows);
                    setActiveTab("builder");
                  }} 
                  overrideData={spreadsheetOverride}
                  onClearOverride={() => setSpreadsheetOverride(null)}
                />
              </motion.div>
            )}

            {activeTab === "builder" && (
              <motion.div
                key="builder"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18 }}
              >
                <IntegramBuilder 
                  spreadsheetColumns={builderColumns}
                  spreadsheetRows={builderRows}
                  activeSpreadsheetTab={() => setActiveTab("spreadsheet")}
                />
              </motion.div>
            )}

            {activeTab === "converters" && (
              <motion.div
                key="converters"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18 }}
              >
                <Converters 
                  onLoadParsedData={handleLoadDataIntoSpreadsheet} 
                  activeSpreadsheetTab={() => setActiveTab("spreadsheet")}
                />
              </motion.div>
            )}

            {activeTab === "seo" && (
              <motion.div
                key="seo"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18 }}
              >
                <SEOContent 
                  onLoadExample={handleLoadDataIntoSpreadsheet}
                  activeSpreadsheetTab={() => setActiveTab("spreadsheet")}
                />
              </motion.div>
            )}

            {activeTab === "sync" && (
              <motion.div
                key="sync"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.18 }}
              >
                <AuthSync 
                  session={session}
                  onLogin={(s) => {
                    handleLoginBackend(s.email || "demo@integram.ru", s.name || "Пользователь", s.avatar || "", s.provider || "google");
                  }}
                  onLogout={handleLogout}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Integram Banner / Direct Lead Capture Funnel (Bottom Anchor) */}
        <section id="integram-banner" className="pt-4 border-t border-slate-200">
          <IntegramBanner />
        </section>

        {/* SEO and informative optimized Russian text footer */}
        <footer className="bg-white border border-slate-200 rounded-2xl p-6 md:p-8 space-y-6 text-xs text-slate-500 leading-relaxed">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h5 className="font-bold text-slate-700 mb-2">О платформе Интеграм АИ</h5>
              <p>
                Интеграм АИ — это инновационное веб-решение, предназначенное для автоматизации работы с электронными таблицами. Мы верим, что рутинный ввод данных, объединение таблиц в Excel и парсинг ячеек должны остаться в прошлом. Наша цель — разблокировать потенциал каждого сотрудника, превратив обычные данные в полноценные ИТ-инструменты без единой строчки кода.
                Узнайте больше на <a href="https://ideav.ru/excel-to-app.html" target="_blank" rel="noopener noreferrer" className="text-indigo-600 font-semibold hover:underline">https://ideav.ru/excel-to-app.html</a>.
              </p>
            </div>
            <div>
              <h5 className="font-bold text-slate-700 mb-2">Продвинутое OCR и ИИ-Конвертация</h5>
              <p>
                Используя передовые разработки в области компьютерного зрения и распознавания образов на базе ИИ Gemini 3.5, наш сервис осуществляет точное распознавание печатных и рукописных таблиц с фотографий и PDF документов. Интегрированные конвертеры позволяют мгновенно преобразовывать PDF в Excel, Excel в PDF, CSV в Excel, и JSON в Excel прямо в браузере.
              </p>
            </div>
            <div>
              <h5 className="font-bold text-slate-700 mb-2">Сквозная Синхронизация и Безопасность</h5>
              <p>
                Синхронизируйте свои отчеты и выписки между настольными ПК и мобильными телефонами. Благодаря встроенной облачной СУБД со сквозным шифрованием (AES-256), ваши данные надежно защищены. Вы можете отредактировать нужные формулы на планшете в пути, а затем продолжить экспорт финансового отчета на ПК.
              </p>
            </div>
          </div>
          <div className="border-t border-slate-100 pt-4 text-center text-[10px] text-slate-400">
            © {new Date().getFullYear()} Интеграм АИ (Integram AI). Все права защищены. Разработано с любовью к автоматизации и структурированным данным. Все ссылки ведут на официальную платформу <a href="https://ideav.ru/excel-to-app.html" target="_blank" rel="noopener noreferrer" className="text-indigo-500 font-semibold hover:underline">ideav.ru/excel-to-app.html</a>.
          </div>
        </footer>

      </div>

      {/* FLOATING TELEGRAM CHAT WIDGET - INTERACTION WITH @INTEGRAMMBOT */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
        
        {/* Toggle Button */}
        <motion.button
          onClick={() => setIsChatOpen(!isChatOpen)}
          className="bg-linear-to-tr from-sky-500 to-sky-600 hover:from-sky-600 hover:to-sky-700 text-white p-3.5 rounded-full shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer focus:outline-hidden"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          id="tg-bot-toggle-btn"
        >
          <MessageCircle className="w-6 h-6 animate-pulse" />
          <span className="text-xs font-bold hidden md:inline pr-1">Чат с @Integrammbot</span>
          {session.provider === "telegram" && (
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-white rounded-full" />
          )}
        </motion.button>

        {/* Chat Window */}
        <AnimatePresence>
          {isChatOpen && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className="bg-white border border-slate-200 rounded-2xl shadow-2xl w-[340px] sm:w-[400px] h-[480px] mt-3 flex flex-col overflow-hidden"
            >
              {/* Chat Header */}
              <div className="bg-sky-500 text-white px-4 py-3 flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-bold text-sky-100">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold leading-tight">Integrammbot ⚡️</h4>
                    <span className="text-[9px] text-sky-100 font-semibold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                      ИИ Ассистент на связи
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <a 
                    href="https://t.me/Integrammbot" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-[10px] bg-white/20 hover:bg-white/30 px-2 py-0.5 rounded-full font-bold text-white transition-colors"
                  >
                    t.me/Integrammbot
                  </a>
                  <button 
                    onClick={() => setIsChatOpen(false)}
                    className="text-white hover:text-sky-100 font-extrabold text-sm p-1"
                  >
                    &times;
                  </button>
                </div>
              </div>

              {/* Telegram Sync Alert if not authorized in TG */}
              {session.provider !== "telegram" && (
                <div className="bg-sky-50 border-b border-sky-100 px-3.5 py-2 flex items-center justify-between text-[10px] text-sky-800">
                  <span className="font-semibold leading-snug">
                    👉 Авторизуйтесь через Telegram в шапке, чтобы получить спец-привилегии!
                  </span>
                  <button 
                    onClick={() => handleLoginBackend("telegram.user@t.me", "Телеграм Пользователь", "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100", "telegram")}
                    className="text-[9px] bg-sky-600 text-white font-bold px-2 py-1 rounded hover:bg-sky-700 shrink-0 cursor-pointer"
                  >
                    Войти
                  </button>
                </div>
              )}

              {/* Chat Messages Logs */}
              <div className="flex-1 overflow-y-auto p-4 bg-slate-50 space-y-3 scrollbar-thin">
                {chatMessages.map((msg, index) => (
                  <div
                    key={index}
                    className={`flex flex-col ${msg.sender === "user" ? "items-end" : "items-start"}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-xs leading-relaxed shadow-3xs ${
                        msg.sender === "user"
                          ? "bg-sky-500 text-white rounded-tr-xs"
                          : "bg-white text-slate-800 border border-slate-200 rounded-tl-xs"
                      }`}
                    >
                      <p className="whitespace-pre-line">{msg.text}</p>
                      <span className={`block text-[8px] text-right mt-1 ${msg.sender === "user" ? "text-sky-100" : "text-slate-400"}`}>
                        {msg.time}
                      </span>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex items-center gap-1.5 bg-white border border-slate-200 px-3 py-2 rounded-2xl w-24 shadow-3xs">
                    <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" />
                    <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                    <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                  </div>
                )}
              </div>

              {/* Chat Input form */}
              <form onSubmit={handleSendChatMessage} className="p-3 bg-white border-t border-slate-200 flex gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Задайте вопрос про формулу или Integram AI..."
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:outline-hidden focus:border-sky-400 transition-colors"
                />
                <button
                  type="submit"
                  className="bg-sky-500 hover:bg-sky-600 text-white p-2.5 rounded-xl flex items-center justify-center transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>

              {/* Bot Meta Footer */}
              <div className="bg-slate-100 text-[9px] text-center text-slate-400 py-1.5 border-t border-slate-200 font-semibold select-none">
                Официальный ИИ-канал связи с ботом поддержки Integrammbot
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

    </div>
  );
}
