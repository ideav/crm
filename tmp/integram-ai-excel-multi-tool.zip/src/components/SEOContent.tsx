import React, { useState } from "react";
import { SEO_ARTICLES } from "../data/seoArticles";
import { SEOArticle } from "../types";
import { 
  BookOpen, 
  Search, 
  ExternalLink, 
  Play, 
  HelpCircle, 
  Code,
  Tag,
  ChevronRight,
  Sparkles,
  Award
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface SEOContentProps {
  onLoadExample: (data: { columns: string[]; rows: string[][] }) => void;
  activeSpreadsheetTab: () => void;
}

export default function SEOContent({ onLoadExample, activeSpreadsheetTab }: SEOContentProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<"all" | "basic" | "formulas" | "automation" | "tables">("all");
  const [selectedArticle, setSelectedArticle] = useState<SEOArticle | null>(SEO_ARTICLES[0]);

  // Filtering articles
  const filteredArticles = SEO_ARTICLES.filter(art => {
    const matchesSearch = 
      art.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.keywords.some(k => k.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === "all" || art.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const categories = [
    { id: "all", label: "Все статьи" },
    { id: "basic", label: "Основы Excel" },
    { id: "formulas", label: "Формулы и расчеты" },
    { id: "tables", label: "Управление таблицами" },
    { id: "automation", label: "Автоматизация" }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Left Column: Search & Articles List */}
      <div className="lg:col-span-5 space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Поиск по базе знаний (например: ВПР, ячейка...)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 shadow-2xs"
          />
        </div>

        {/* Category Filter Chips */}
        <div className="flex flex-wrap gap-1.5">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as any)}
              className={`px-3 py-1.5 rounded-full text-[10px] font-semibold transition-all cursor-pointer ${selectedCategory === cat.id ? "bg-indigo-600 text-white shadow-xs" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Article Cards */}
        <div className="space-y-2.5 max-h-[580px] overflow-y-auto pr-1">
          {filteredArticles.length > 0 ? (
            filteredArticles.map(art => {
              const isSelected = selectedArticle?.id === art.id;
              return (
                <div
                  key={art.id}
                  onClick={() => setSelectedArticle(art)}
                  className={`p-4 rounded-xl border text-left cursor-pointer transition-all ${isSelected ? "border-indigo-600 bg-indigo-50/20 shadow-xs" : "border-slate-200 bg-white hover:border-slate-300 hover:shadow-2xs"}`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${art.category === "basic" ? "bg-blue-100 text-blue-700" : art.category === "formulas" ? "bg-purple-100 text-purple-700" : art.category === "tables" ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"}`}>
                      {art.category === "basic" && "Основы"}
                      {art.category === "formulas" && "Формулы"}
                      {art.category === "tables" && "Таблицы"}
                      {art.category === "automation" && "Автоматизация"}
                    </span>
                    {art.exampleData && (
                      <span className="text-[9px] text-indigo-600 font-bold bg-indigo-50 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                        <Play className="w-2.5 h-2.5 fill-indigo-600" />
                        Есть Демо
                      </span>
                    )}
                  </div>
                  <h5 className="font-bold text-slate-800 text-xs line-clamp-2 leading-relaxed mb-1">{art.title}</h5>
                  <p className="text-[10px] text-slate-500 line-clamp-2">{art.summary}</p>
                </div>
              );
            })
          ) : (
            <div className="text-center py-12 text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
              <p className="text-xs">Статьи не найдены</p>
              <span className="text-[10px]">Попробуйте другой поисковый запрос</span>
            </div>
          )}
        </div>
      </div>

      {/* Right Column: Detailed Reader and Playground Sync */}
      <div className="lg:col-span-7">
        <AnimatePresence mode="wait">
          {selectedArticle ? (
            <motion.div
              key={selectedArticle.id}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.15 }}
              className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6 shadow-xs h-full flex flex-col justify-between"
            >
              <div className="space-y-4">
                {/* Meta details */}
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <BookOpen className="w-4 h-4 text-slate-400" />
                  <span>Категория:</span>
                  <span className="font-semibold text-slate-700 capitalize">
                    {selectedArticle.category === "basic" && "Базовый уровень"}
                    {selectedArticle.category === "formulas" && "Формулы и Спецификации"}
                    {selectedArticle.category === "tables" && "Табличный дизайн"}
                    {selectedArticle.category === "automation" && "Автоматизированная обработка"}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-base leading-snug md:text-lg">
                  {selectedArticle.title}
                </h3>

                {/* Main Text Content */}
                <div className="text-slate-600 text-xs leading-relaxed space-y-3 whitespace-pre-line border-t border-b border-slate-100 py-4">
                  {selectedArticle.content}
                </div>

                {/* Keywords and SEO tags */}
                <div className="flex flex-wrap gap-1 items-center">
                  <Tag className="w-3.5 h-3.5 text-slate-400 mr-1" />
                  {selectedArticle.keywords.map(kw => (
                    <span key={kw} className="text-[10px] bg-slate-50 text-slate-500 border border-slate-200 px-2.5 py-0.5 rounded-full">
                      #{kw}
                    </span>
                  ))}
                </div>

                {/* Cross Links to other relevant articles */}
                {selectedArticle.crossLinks.length > 0 && (
                  <div className="pt-2">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">Связанные темы:</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedArticle.crossLinks.map((link, idx) => {
                        const matchedArt = SEO_ARTICLES.find(a => a.slug === link.slug);
                        return (
                          <button
                            key={idx}
                            onClick={() => matchedArt && setSelectedArticle(matchedArt)}
                            className="inline-flex items-center gap-1 text-[10px] font-semibold text-indigo-600 hover:text-indigo-800 hover:underline bg-indigo-50/50 px-2.5 py-1 rounded-lg cursor-pointer"
                          >
                            {link.text}
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Loader into sheets - Interactive UI hook */}
              {selectedArticle.exampleData && (
                <div className="mt-6 p-4 bg-linear-to-r from-indigo-50 to-indigo-100 rounded-xl border border-indigo-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-600 text-white rounded-lg">
                      <Play className="w-4 h-4 fill-white" />
                    </div>
                    <div>
                      <h5 className="font-semibold text-xs text-indigo-950">Интерактивный практикум</h5>
                      <p className="text-[10px] text-indigo-700">
                        Загрузите тестовые данные из этой статьи напрямую в наш редактор
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      if (selectedArticle.exampleData) {
                        onLoadExample(selectedArticle.exampleData);
                        activeSpreadsheetTab();
                      }
                    }}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-[10px] shadow-xs cursor-pointer transition-colors"
                  >
                    <span>Запустить практикум</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              )}
            </motion.div>
          ) : (
            <div className="h-full border border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center p-12 text-center text-slate-400 bg-slate-50/50">
              <BookOpen className="w-8 h-8 mb-2" />
              <p className="text-xs">Выберите статью в левой колонке для чтения</p>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
