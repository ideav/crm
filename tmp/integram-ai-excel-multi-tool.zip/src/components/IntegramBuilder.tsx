import React, { useState } from "react";
import * as XLSX from "xlsx";
import { 
  Wand2, 
  Sparkles, 
  Check, 
  ArrowRight, 
  Database, 
  Layout, 
  ShieldCheck, 
  Copy, 
  RefreshCw, 
  CheckSquare, 
  ChevronRight, 
  Terminal, 
  Code2, 
  FileCode, 
  Eye, 
  Briefcase, 
  Users, 
  Compass, 
  ListTodo,
  ExternalLink,
  Upload,
  FileSpreadsheet,
  AlertCircle,
  Wrench
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface TableColumn {
  id: string;
  name: string;
  format: string;
}

interface IntegramTable {
  id: string;
  name: string;
  columns: TableColumn[];
  relations: string;
}

interface UserJourney {
  role: string;
  journey: string;
  description: string;
}

interface IntegramWorkflow {
  isFallback?: boolean;
  step1_consolidation: {
    businessDomain: string;
    userJourneys: UserJourney[];
    requirementsChecklist: string[];
  };
  step2_schema: {
    tables: IntegramTable[];
  };
  step3_script: {
    payloadJson: string;
    scriptExplanation: string;
  };
  step4_templates: {
    htmlCode: string;
    jsCode: string;
    cssNotes: string;
  };
  step5_roles_permissions: {
    roles: Array<{ name: string; mask: string; tablesAccess: string }>;
    menuItems: string[];
    demoUsers: Array<{ role: string; login: string; password?: string; password_hash?: string; description: string }>;
  };
  step6_seeding: {
    seedPayload: string;
    instructions: string;
  };
  step7_checklist: string[];
}

const CRM_TEMPLATES = [
  {
    id: "b2b_sales",
    title: "B2B / B2C Продажи",
    description: "Ведение сделок, этапы воронки, сделки и оплаты менеджеров.",
    appName: "CRM Отдел Продаж",
    appDesc: "Система ведения клиентов, учета сделок, контроля воронки продаж и оплат.",
    columns: ["ФИО Клиента", "Компания", "Телефон", "Email", "Сумма Сделки", "Статус Сделки", "Дата Контакта", "Менеджер", "Комментарий"],
    rows: [
      ["Иван Петров", "Вектор Плюс", "+7 (999) 111-22-33", "petrov@vector.ru", "150000", "Новая заявка", "2026-06-25", "Иван Громов", "Запросил коммерческое предложение"],
      ["Елена Смирнова", "Смирнова ИП", "+7 (999) 555-66-77", "smi@elena.ru", "85000", "Согласование договора", "2026-06-24", "Анна Смирнова", "Договор отправлен на почту"],
      ["Дмитрий Орлов", "ООО Космос", "+7 (911) 555-44-33", "orlov@cosmos.com", "420000", "Успешно завершена", "2026-06-20", "Иван Громов", "Оплата получена, отгрузка выполнена"]
    ]
  },
  {
    id: "service_repair",
    title: "Автосервис & Заказы",
    description: "Учет автомобилей, заказ-нарядов, мастеров и стоимости услуг.",
    appName: "CRM Автосервис & Заказ-Наряды",
    appDesc: "Система регистрации автомобилей, ремонта, заменяемых деталей и расчета стоимости услуг.",
    columns: ["Марка Модель", "Гос Номер", "Владелец", "Телефон владельца", "Описание проблемы", "Назначенный мастер", "Статус ремонта", "Стоимость услуг", "Дата заезда"],
    rows: [
      ["Toyota Camry", "А123АА77", "Сергей Громов", "+7 (903) 777-88-99", "Замена тормозных колодок и дисков", "Григорий", "В ремонте", "6500", "2026-06-25"],
      ["Kia Rio", "О444ОО199", "Мария Соколова", "+7 (909) 111-44-55", "Регулярное ТО-3, замена свечей", "Сергей", "Завершено", "8200", "2026-06-24"]
    ]
  },
  {
    id: "helpdesk",
    title: "Поддержка & Заявки",
    description: "Учет тикетов от клиентов, категории, приоритеты и инженеры.",
    appName: "CRM Служба Поддержки",
    appDesc: "Менеджер обращений клиентов, статусы заявок, категории и исполнители.",
    columns: ["Номер Заявки", "Тема Обращения", "Имя Клиента", "Контакты", "Приоритет", "Категория", "Назначен Кому", "Статус Заявки", "Дата Создания"],
    rows: [
      ["1001", "Не работает вход в кабинет", "Алексей", "alex@mail.ru", "Высокий", "Авторизация", "Дмитрий", "В работе", "2026-06-25"],
      ["1002", "Запрос на закрывающие документы", "Ольга", "@olga_buh", "Низкий", "Бухгалтерия", "Анна Смирнова", "Выполнено", "2026-06-23"]
    ]
  },
  {
    id: "tasks_kanban",
    title: "Управление Задачами",
    description: "Контроль выполнения проектов, задач, дедлайнов и прогресса.",
    appName: "CRM Управление Задачами & Kanban",
    appDesc: "Система планирования задач, ответственных исполнителей, приоритетов и контроля дедлайнов.",
    columns: ["Название задачи", "Описание задачи", "Проект", "Ответственный", "Срок сдачи", "Приоритет", "Статус задачи", "Прогресс (%)"],
    rows: [
      ["Отредактировать договор", "Добавить пункт про неустойку и согласовать", "Альфа", "Анна Смирнова", "2026-06-28", "Средний", "Не начато", "0%"],
      ["Подготовить отчет за Q2", "Собрать данные от всех отделов в Excel", "Аналитика", "Иван Громов", "2026-06-26", "Высокий", "В процессе", "60%"]
    ]
  }
];

interface IntegramBuilderProps {
  spreadsheetColumns: string[];
  spreadsheetRows: string[][];
  activeSpreadsheetTab: () => void;
}

export default function IntegramBuilder({
  spreadsheetColumns,
  spreadsheetRows,
  activeSpreadsheetTab
}: IntegramBuilderProps) {
  const [appName, setAppName] = useState("");
  const [appDesc, setAppDesc] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [workflow, setWorkflow] = useState<IntegramWorkflow | null>(null);
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [isPublished, setIsPublished] = useState(false);
  const [activeCodeTab, setActiveCodeTab] = useState<"html" | "js" | "css">("html");

  // Local state for column structures & rows (can be from Excel file or spreadsheet props)
  const [localColumns, setLocalColumns] = useState<string[]>(spreadsheetColumns || []);
  const [localRows, setLocalRows] = useState<string[][]>(spreadsheetRows || []);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // Sync if props are modified and we don't have an actively uploaded custom file
  React.useEffect(() => {
    if (spreadsheetColumns && spreadsheetColumns.length > 0 && !uploadedFileName) {
      setLocalColumns(spreadsheetColumns);
    }
  }, [spreadsheetColumns, uploadedFileName]);

  React.useEffect(() => {
    if (spreadsheetRows && spreadsheetRows.length > 0 && !uploadedFileName) {
      setLocalRows(spreadsheetRows);
    }
  }, [spreadsheetRows, uploadedFileName]);

  // Local checkbox state for Step 7 manual testing
  const [checkedItems, setCheckedItems] = useState<Record<number, boolean>>({});

  // Simulated Integram Platform Workspace state
  const [simLogin, setSimLogin] = useState("");
  const [simPassword, setSimPassword] = useState("");
  const [simLoggedInUser, setSimLoggedInUser] = useState<any | null>(null);
  const [simTablesData, setSimTablesData] = useState<Record<string, any[]>>({});
  const [simSearchQuery, setSimSearchQuery] = useState("");
  const [simNewRecord, setSimNewRecord] = useState<Record<string, any>>({});
  const [simActiveTableId, setSimActiveTableId] = useState<string>("");
  const [simLoginError, setSimLoginError] = useState<string | null>(null);

  React.useEffect(() => {
    if (workflow) {
      const initialData: Record<string, any[]> = {};
      const tables = workflow.step2_schema?.tables || [];
      if (tables.length > 0) {
        setSimActiveTableId(tables[0].id);
      }
      
      let parsedSeed: any = null;
      try {
        if (workflow.step6_seeding?.seedPayload) {
          parsedSeed = JSON.parse(workflow.step6_seeding.seedPayload);
        }
      } catch (e) {
        console.warn("Failed to parse seed payload", e);
      }
      
      tables.forEach(table => {
        let rows: any[] = [];
        if (parsedSeed) {
          const matchingKey = Object.keys(parsedSeed).find(k => 
            k.toLowerCase().includes(table.id.toLowerCase()) && Array.isArray(parsedSeed[k])
          );
          if (matchingKey) {
            rows = [...parsedSeed[matchingKey]];
          }
        }
        
        if (rows.length === 0) {
          rows = localRows.slice(0, 5).map((row, rIdx) => {
            const record: any = { id: `r_${rIdx + 1}` };
            table.columns.forEach((col, cIdx) => {
              record[col.id] = row[cIdx] || "";
            });
            return record;
          });
        }
        
        initialData[table.id] = rows;
      });
      
      setSimTablesData(initialData);
      setSimLoggedInUser(null);
      setSimLoginError(null);
      setSimSearchQuery("");
      setSimNewRecord({});
    }
  }, [workflow, localRows]);

  const handleSimLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!workflow) return;
    
    const demoUsers = workflow.step5_roles_permissions?.demoUsers || [];
    const matched = demoUsers.find(u => 
      u.login.trim().toLowerCase() === simLogin.trim().toLowerCase() &&
      (u.password || "123").trim() === simPassword.trim()
    );
    
    if (matched) {
      setSimLoggedInUser(matched);
      setSimLoginError(null);
    } else {
      setSimLoginError("Неверный логин или пароль. Пожалуйста, скопируйте корректные реквизиты доступа из Шага #5 или кликните по демо-пользователю для автозаполнения.");
    }
  };

  const handleQuickSimLogin = (user: any) => {
    setSimLogin(user.login);
    setSimPassword(user.password || "");
    setSimLoggedInUser(user);
    setSimLoginError(null);
  };

  const handleAddSimRow = (e: React.FormEvent) => {
    e.preventDefault();
    if (!workflow || !simLoggedInUser || !simActiveTableId) return;
    
    const activeTable = workflow.step2_schema?.tables?.find(t => t.id === simActiveTableId);
    if (!activeTable) return;
    
    const userRole = workflow?.step5_roles_permissions?.roles?.find(r => r.name === simLoggedInUser.role) || { mask: "WRITE, READ" };
    const hasWrite = userRole.mask.includes("WRITE") || userRole.mask.includes("ADMIN");
    
    if (!hasWrite) {
      alert(`Ошибка доступа! Роль "${simLoggedInUser.role}" имеет маску прав: "${userRole.mask}". Создание записей заблокировано.`);
      return;
    }
    
    const newId = `new_${Date.now()}`;
    const record: any = { id: newId };
    
    activeTable.columns.forEach(col => {
      let val = simNewRecord[col.id] || "";
      if (col.format === "t=num") {
        const num = parseFloat(String(val).replace(/[^0-9.-]/g, ""));
        val = isNaN(num) ? 0 : num;
      }
      record[col.id] = val;
    });
    
    setSimTablesData(prev => ({
      ...prev,
      [simActiveTableId]: [...(prev[simActiveTableId] || []), record]
    }));
    
    setSimNewRecord({});
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleImportFromSpreadsheet = () => {
    if (spreadsheetColumns.length === 0) return;
    setLocalColumns(spreadsheetColumns);
    setLocalRows(spreadsheetRows);
    setUploadedFileName(null);
    setUploadError(null);
    setAppName("Приложение из таблицы Excel");
    setAppDesc(`Система на основе колонок: ${spreadsheetColumns.slice(0, 5).join(", ")}...`);
  };

  const handleSelectTemplate = (tpl: typeof CRM_TEMPLATES[number]) => {
    setAppName(tpl.appName);
    setAppDesc(tpl.appDesc);
    setLocalColumns(tpl.columns);
    setLocalRows(tpl.rows);
    setUploadedFileName(`Шаблон: ${tpl.title}`);
    setUploadError(null);
  };

  const parseExcelFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: "binary" });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        const json: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        if (json && json.length > 0) {
          const cols: string[] = json[0]
            .map((c: any) => String(c || "").trim())
            .filter(Boolean);
            
          const rows: string[][] = json.slice(1).map((r: any[]) => 
            (r || []).map((val: any) => String(val ?? ""))
          );
          
          if (cols.length > 0) {
            setLocalColumns(cols);
            setLocalRows(rows);
            setUploadedFileName(file.name);
            setAppName(file.name.replace(/\.[^/.]+$/, ""));
            setAppDesc(`No-code приложение на основе колонок из файла "${file.name}": ${cols.slice(0, 4).join(", ")}`);
            setUploadError(null);
          } else {
            setUploadError("Не удалось найти заголовки колонок в файле.");
          }
        } else {
          setUploadError("Файл пуст или имеет неверный формат.");
        }
      } catch (err: any) {
        console.error("Error reading file:", err);
        setUploadError(`Ошибка обработки файла: ${err?.message || err}`);
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      parseExcelFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      parseExcelFile(file);
    }
  };

  const clearUploadedFile = () => {
    setUploadedFileName(null);
    setUploadError(null);
    if (spreadsheetColumns && spreadsheetColumns.length > 0) {
      setLocalColumns(spreadsheetColumns);
      setLocalRows(spreadsheetRows);
      setAppName("Приложение из таблицы Excel");
      setAppDesc(`Система на основе колонок: ${spreadsheetColumns.slice(0, 5).join(", ")}...`);
    } else {
      setLocalColumns([]);
      setLocalRows([]);
      setAppName("");
      setAppDesc("");
    }
  };

  const triggerBuild = async () => {
    setIsLoading(true);
    setLogs([]);
    setWorkflow(null);
    setCurrentStep(1);
    setIsPublished(false);

    const logSteps = [
      "⚡ Инициация сессии проектирования Integram...",
      "🔍 Чтение исходных метаданных и колонок листа...",
      "🧠 Анализ бизнес-сценариев и генерация User Journeys...",
      "📋 Консолидация ТЗ на low-code приложение...",
      "🗄️ Проектирование схемы СУБД по спецификации StructureRules.md...",
      "🔗 Построение реляционных связей Lookups (t=ref)...",
      "⚙️ Компиляция idempotent-скрипта API (_d_new)...",
      "🎨 Верстка адаптивного HTML рабочего места под Tailwind...",
      "🔌 Написание клиентской автоматизации на чистом JavaScript...",
      "🛡️ Разграничение прав доступа и ролевых масок...",
      "💾 Генерация seed-пакетов данных для API _d_req...",
      "✨ Проект успешно скомпилирован!"
    ];

    // Simulate real-time compiler logs
    for (let i = 0; i < logSteps.length; i++) {
      setLogs(prev => [...prev, logSteps[i]]);
      await new Promise(resolve => setTimeout(resolve, 250));
    }

    try {
      const response = await fetch("/api/integram/generate-workflow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          appName: appName || "Умное Integram Приложение",
          description: appDesc || "No-code система на базе таблиц.",
          spreadsheetColumns: localColumns,
          spreadsheetRows: localRows.slice(0, 5)
        })
      });

      if (!response.ok) {
        throw new Error("Ошибка связи с сервером при генерации.");
      }

      const data = await response.json();
      setWorkflow(data);
    } catch (err) {
      console.error(err);
      setLogs(prev => [...prev, "❌ Ошибка компиляции. Использован аварийный fallback."]);
    } finally {
      setIsLoading(false);
    }
  };

  const steps = [
    { num: 1, label: "ТЗ и Роли" },
    { num: 2, label: "Схема СУБД" },
    { num: 3, label: "API-скрипт" },
    { num: 4, label: "HTML/JS" },
    { num: 5, label: "Права доступа" },
    { num: 6, label: "Тестовые данные" },
    { num: 7, label: "Запуск" }
  ];

  return (
    <div className="space-y-6">
      {/* Upper info block */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row gap-6 justify-between items-start md:items-center">
          <div className="space-y-1.5 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-[10px] font-bold border border-indigo-100 uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              Официальный Integram Workflow
            </div>
            <h1 className="text-xl font-extrabold tracking-tight text-slate-900 md:text-2xl">
              ИИ No-Code Конструктор Приложений
            </h1>
            <p className="text-xs text-slate-500 leading-relaxed">
              Превратите Excel-структуру в полноценное корпоративное веб-приложение с СУБД, 
              ролевой моделью и API по стандартам платформы <strong>Integram AI</strong>.
            </p>
          </div>
          {spreadsheetColumns.length > 0 && !workflow && (
            <button
              onClick={handleImportFromSpreadsheet}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold cursor-pointer transition-colors shrink-0"
            >
              <RefreshCw className="w-4 h-4 text-indigo-500" />
              Импортировать Excel-колонки
            </button>
          )}
        </div>

        {/* Setup configuration form */}
        {!workflow && !isLoading && (
          <div className="mt-6 border-t border-slate-100 pt-6 space-y-6">
            
            {/* CRM Template Selector */}
            <div className="bg-slate-50/50 border border-slate-200/60 p-5 rounded-2xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="space-y-0.5">
                  <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-indigo-500 animate-pulse" />
                    Быстрый выбор готового CRM-шаблона без Excel
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Выберите готовую структуру CRM, и ИИ-конструктор автоматически настроит таблицы, поля и демо-данные!
                  </p>
                </div>
                <span className="self-start sm:self-center px-2 py-0.5 bg-indigo-50 text-indigo-600 font-bold rounded-md text-[10px] uppercase tracking-wider border border-indigo-100/60">
                  Рекомендуем
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                {CRM_TEMPLATES.map((tpl) => {
                  const isSelected = appName === tpl.appName;
                  return (
                    <button
                      key={tpl.id}
                      onClick={() => handleSelectTemplate(tpl)}
                      className={`text-left p-4 rounded-xl border bg-white transition-all cursor-pointer flex flex-col justify-between group h-full hover:shadow-xs relative ${
                        isSelected 
                          ? "border-indigo-600 ring-2 ring-indigo-600/15" 
                          : "border-slate-200/80 hover:border-indigo-400"
                      }`}
                    >
                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between">
                          <div className={`p-2 rounded-lg border ${
                            isSelected 
                              ? "bg-indigo-50 border-indigo-100 text-indigo-600" 
                              : "bg-slate-50 border-slate-100 text-slate-500 group-hover:text-indigo-600 group-hover:bg-indigo-50/50 group-hover:border-indigo-100/30"
                          } transition-colors`}>
                            {tpl.id === "b2b_sales" && <Briefcase className="w-4.5 h-4.5" />}
                            {tpl.id === "service_repair" && <Wrench className="w-4.5 h-4.5" />}
                            {tpl.id === "helpdesk" && <Compass className="w-4.5 h-4.5" />}
                            {tpl.id === "tasks_kanban" && <ListTodo className="w-4.5 h-4.5" />}
                          </div>
                          {isSelected && (
                            <span className="bg-indigo-600 text-white p-0.5 rounded-full">
                              <Check className="w-3 h-3" />
                            </span>
                          )}
                        </div>

                        <div className="space-y-1">
                          <h4 className="font-bold text-xs text-slate-800 tracking-tight group-hover:text-indigo-600 transition-colors">
                            {tpl.title}
                          </h4>
                          <p className="text-[10px] text-slate-500 leading-normal line-clamp-2">
                            {tpl.description}
                          </p>
                        </div>
                      </div>

                      <div className="border-t border-slate-100 pt-2.5 mt-3 flex items-center justify-between text-[9px] text-slate-400 font-medium">
                        <span>Колонок: {tpl.columns.length}</span>
                        <span className="flex items-center gap-0.5 text-indigo-600 font-semibold group-hover:translate-x-0.5 transition-transform">
                          Выбрать <ArrowRight className="w-2.5 h-2.5" />
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Column: Form Parameters */}
              <div className="lg:col-span-7 space-y-4">
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <Layout className="w-4 h-4 text-indigo-500" />
                  Параметры будущего No-Code приложения
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1.5">Имя вашего приложения</label>
                    <input
                      type="text"
                      placeholder="Например: CRM Автомастерская"
                      value={appName}
                      onChange={e => setAppName(e.target.value)}
                      className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:border-indigo-500 focus:outline-hidden bg-slate-50/50"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-600 mb-1.5">Что должно делать? (Бизнес-описание)</label>
                    <input
                      type="text"
                      placeholder="Например: Учет заказов, статусов ремонта и цен."
                      value={appDesc}
                      onChange={e => setAppDesc(e.target.value)}
                      className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:border-indigo-500 focus:outline-hidden bg-slate-50/50"
                    />
                  </div>
                </div>

                {/* Source status badge */}
                <div className="p-3 bg-slate-50 border border-slate-200/60 rounded-xl flex items-center justify-between text-[11px] text-slate-600 gap-3">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-slate-400" />
                    <span>
                      {uploadedFileName ? (
                        uploadedFileName.startsWith("Шаблон:") ? (
                          <>
                            Источник: ИИ-шаблон <strong className="text-indigo-600 font-bold">{uploadedFileName.replace("Шаблон:", "")}</strong>
                          </>
                        ) : (
                          <>
                            Источник: Файл <strong className="text-emerald-700">{uploadedFileName}</strong>
                          </>
                        )
                      ) : localColumns.length > 0 ? (
                        <>
                          Источник: <strong className="text-indigo-700">Активный лист Редактора Таблиц</strong>
                        </>
                      ) : (
                        <span className="text-amber-600 font-semibold flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" />
                          Нет источника колонок. Выберите шаблон CRM выше, загрузите файл или заполните таблицу.
                        </span>
                      )}
                    </span>
                  </div>

                  {uploadedFileName ? (
                    <button
                      onClick={clearUploadedFile}
                      className="text-red-500 hover:text-red-700 font-bold hover:underline cursor-pointer"
                    >
                      Сбросить шаблон/файл
                    </button>
                  ) : spreadsheetColumns.length > 0 && localColumns !== spreadsheetColumns ? (
                    <button
                      onClick={handleImportFromSpreadsheet}
                      className="text-indigo-600 hover:text-indigo-800 font-bold hover:underline cursor-pointer"
                    >
                      Использовать лист редактора
                    </button>
                  ) : null}
                </div>

                {/* Local Columns Preview if available */}
                {localColumns.length > 0 && (
                  <div className="space-y-1.5">
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                      Обнаружено колонок ({localColumns.length}):
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {localColumns.slice(0, 8).map((col, cIdx) => (
                        <span key={cIdx} className="px-2 py-1 bg-slate-100 text-slate-600 text-[10px] rounded-md font-mono font-medium border border-slate-200/50">
                          {col}
                        </span>
                      ))}
                      {localColumns.length > 8 && (
                        <span className="px-2 py-1 bg-slate-50 text-slate-400 text-[10px] rounded-md border border-dashed border-slate-200">
                          +{localColumns.length - 8} еще
                        </span>
                      )}
                    </div>
                  </div>
                )}

                <div className="pt-2">
                  <button
                    onClick={triggerBuild}
                    disabled={localColumns.length === 0}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed text-white font-bold py-3.5 px-6 rounded-xl text-xs transition-all cursor-pointer shadow-sm"
                  >
                    <Wand2 className="w-4 h-4" />
                    Собрать приложение по структуре
                  </button>
                </div>
              </div>

              {/* Right Column: Excel File Upload zone */}
              <div className="lg:col-span-5 flex flex-col justify-between">
                <div className="space-y-2 flex-1 flex flex-col">
                  <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <FileSpreadsheet className="w-4 h-4 text-indigo-500" />
                    Загрузить свой Excel или CSV файл
                  </h3>

                  {/* Drag and Drop Zone Container */}
                  <div
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    className={`flex-1 min-h-[160px] border-2 border-dashed rounded-2xl flex flex-col items-center justify-center p-5 text-center transition-all relative ${
                      isDragging 
                        ? "border-indigo-500 bg-indigo-50/40" 
                        : "border-slate-200 hover:border-indigo-400 hover:bg-slate-50/50"
                    }`}
                  >
                    <input
                      type="file"
                      id="excel-file-upload"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <label
                      htmlFor="excel-file-upload"
                      className="cursor-pointer inset-0 absolute w-full h-full"
                    />

                    <div className="space-y-2.5 pointer-events-none">
                      <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto border border-indigo-100">
                        <Upload className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-700">Перетащите сюда Excel (.xlsx, .xls) или CSV</p>
                        <p className="text-[10px] text-slate-400 mt-0.5">или нажмите для выбора на устройстве</p>
                      </div>
                    </div>
                  </div>

                  {uploadError && (
                    <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-[11px] text-red-600 flex items-start gap-1.5">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{uploadError}</span>
                    </div>
                  )}
                </div>
              </div>

            </div>
          </div>
        )}
      </div>

      {/* Loading state simulator */}
      {isLoading && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 font-mono text-xs text-slate-300 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-indigo-400" />
              <span className="font-bold text-[11px] text-slate-400">компилятор_integram_engine.log</span>
            </div>
            <div className="flex gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
              <span className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
            </div>
          </div>
          <div className="space-y-1.5 max-h-[250px] overflow-y-auto">
            {logs.map((log, index) => (
              <p key={index} className={log.startsWith("❌") ? "text-red-400" : log.startsWith("✨") ? "text-emerald-400 font-bold" : "text-slate-300"}>
                {log}
              </p>
            ))}
          </div>
          <div className="pt-2 flex justify-center">
            <div className="flex items-center gap-2 text-indigo-400 text-[11px]">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              Интеллектуальный синтез структуры...
            </div>
          </div>
        </div>
      )}

      {/* Primary generated workflow steps viewer */}
      {workflow && !isLoading && (
        <div className="space-y-6">
          {workflow.isFallback && (
            <div className="bg-amber-50/70 border border-amber-200/80 rounded-2xl p-4.5 flex gap-4 items-start shadow-xs animate-fade-in">
              <span className="text-xl shrink-0 select-none">⚠️</span>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                  Режим локальной компиляции Integram
                </h4>
                <p className="text-[11px] text-amber-700 leading-relaxed">
                  ИИ-генератор в данный момент испытывает пиковую нагрузку (ошибка 503 от Google Gemini). 
                  Вместо ошибки ваше рабочее место было <strong>успешно собрано</strong> на базе высокоточного 
                  локального low-code генератора Integram! Вы можете полноценно тестировать СУБД, формы и API в демо-режиме.
                </p>
              </div>
            </div>
          )}

          {/* Progress Indicator Steps */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs overflow-x-auto">
            <div className="flex items-center justify-between min-w-[700px] px-2">
              {steps.map((st, sIdx) => {
                const isActive = currentStep === st.num;
                const isPassed = currentStep > st.num;
                return (
                  <React.Fragment key={st.num}>
                    <button
                      onClick={() => setCurrentStep(st.num)}
                      className="flex items-center gap-2 cursor-pointer focus:outline-hidden group"
                    >
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs transition-colors shrink-0 ${
                        isActive 
                          ? "bg-indigo-600 text-white" 
                          : isPassed 
                            ? "bg-emerald-100 text-emerald-800" 
                            : "bg-slate-100 text-slate-500 group-hover:bg-slate-200"
                      }`}>
                        {isPassed ? <Check className="w-3.5 h-3.5 font-bold" /> : st.num}
                      </div>
                      <span className={`text-[11px] font-bold transition-colors ${isActive ? "text-indigo-600" : "text-slate-600"}`}>
                        {st.label}
                      </span>
                    </button>
                    {sIdx < steps.length - 1 && (
                      <ChevronRight className="w-4 h-4 text-slate-300 shrink-0" />
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>

          {/* Stepper Content Area */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs">
            {/* Step 1: Consolidation of requirements */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-800 mb-1">Этап 1: Консолидация ТЗ и бизнес-процессы</h3>
                  <p className="text-xs text-slate-500">Автоматически консолидированное техническое задание на основе анализа предметной области.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Business domain summary box */}
                  <div className="lg:col-span-5 bg-slate-50 rounded-xl border border-slate-200/60 p-4 space-y-3">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <Compass className="w-4 h-4 text-indigo-500" />
                      Бизнес-Домен
                    </h4>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {workflow.step1_consolidation.businessDomain}
                    </p>
                  </div>

                  {/* User Journeys */}
                  <div className="lg:col-span-7 space-y-3">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-indigo-500" />
                      Пользовательские Пути (User Journeys)
                    </h4>
                    <div className="space-y-2.5">
                      {workflow.step1_consolidation.userJourneys.map((j, idx) => (
                        <div key={idx} className="p-3.5 border border-slate-200/80 rounded-xl space-y-1 bg-white hover:border-slate-300 transition-colors">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                              {j.role}
                            </span>
                            <span className="text-[10px] font-semibold text-slate-400">Сценарий #{idx + 1}</span>
                          </div>
                          <h5 className="font-bold text-xs text-slate-800">{j.journey}</h5>
                          <p className="text-[11px] text-slate-500 leading-relaxed">{j.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Requirements check checklist */}
                <div className="border-t border-slate-100 pt-5 space-y-3">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                    <ListTodo className="w-4.5 h-4.5 text-indigo-500" />
                    Критерии функционального соответствия (ТЗ)
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                    {workflow.step1_consolidation.requirementsChecklist.map((req, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 p-3 bg-slate-50 rounded-xl">
                        <div className="p-0.5 bg-emerald-100 text-emerald-800 rounded-md shrink-0 mt-0.5">
                          <Check className="w-3.5 h-3.5 font-bold" />
                        </div>
                        <span className="text-[11px] text-slate-600 leading-snug">{req}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 2: Database Schema */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-800 mb-1">Этап 2: Проектирование схемы СУБД</h3>
                  <p className="text-xs text-slate-500">Логическая и физическая схема таблиц баз данных по спецификациям Integram (StructureRules).</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {workflow.step2_schema.tables.map((table) => (
                    <div key={table.id} className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-xs flex flex-col">
                      {/* Header */}
                      <div className="bg-slate-50 border-b border-slate-200/80 px-4 py-3 flex justify-between items-center">
                        <div>
                          <h4 className="font-bold text-xs text-slate-800">{table.name}</h4>
                          <span className="text-[9px] font-mono text-indigo-600 font-bold bg-indigo-50 px-1.5 py-0.5 rounded-sm">
                            ID: {table.id}
                          </span>
                        </div>
                        <Database className="w-4 h-4 text-slate-400" />
                      </div>

                      {/* Column list */}
                      <div className="p-3 space-y-1.5 flex-1">
                        {table.columns.map((col) => {
                          const isRef = col.format.startsWith("t=ref_");
                          return (
                            <div key={col.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-50/60 border border-slate-100 text-[11px]">
                              <span className="font-semibold text-slate-700">{col.name}</span>
                              <div className="flex items-center gap-1.5 font-mono">
                                <span className="text-[9px] text-slate-400">{col.id}</span>
                                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-sm ${
                                  isRef 
                                    ? "bg-amber-100 text-amber-800" 
                                    : "bg-indigo-50 text-indigo-700"
                                }`}>
                                  {col.format}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* Description relation */}
                      <div className="bg-slate-50/50 p-3 border-t border-slate-100 text-[10px] text-slate-500 leading-normal">
                        <strong>Роль/Связи:</strong> {table.relations}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Helper info banner */}
                <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-xl flex gap-3 text-xs text-indigo-800">
                  <div className="shrink-0 p-1 bg-indigo-100 rounded-lg text-indigo-600 h-fit">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <p className="leading-relaxed">
                    <strong>Связывание таблиц Lookups:</strong> Типы полей <code>t=ref_&#123;таблица&#125;</code> создают строго реляционные связи в Integram. На веб-интерфейсе эти поля будут автоматически отрисованы в виде удобных выпадающих списков выбора контрагентов.
                  </p>
                </div>
              </div>
            )}

            {/* Step 3: API Table-Creation Scripts */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-800 mb-1">Этап 3: Скрипт создания таблиц</h3>
                  <p className="text-xs text-slate-500">Автоматически скомпилированный idempotent JSON-скрипт вызовов к эндпоинту <code>_d_new</code>.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Left column: script view */}
                  <div className="lg:col-span-8 space-y-2">
                    <div className="flex justify-between items-center text-[11px] text-slate-500 font-bold px-1">
                      <span>КОНТРАКТ API (POST _d_new)</span>
                      <button
                        onClick={() => handleCopy(workflow.step3_script.payloadJson, "api_script")}
                        className="inline-flex items-center gap-1 text-indigo-600 hover:text-indigo-800 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        {copiedText === "api_script" ? "Копировано!" : "Копировать код"}
                      </button>
                    </div>

                    <div className="bg-slate-950 p-4 rounded-xl text-xs font-mono text-slate-200 border border-slate-800 max-h-[350px] overflow-y-auto leading-relaxed shadow-inner">
                      <pre>{workflow.step3_script.payloadJson}</pre>
                    </div>
                  </div>

                  {/* Right column: explanation */}
                  <div className="lg:col-span-4 bg-slate-50 border border-slate-200/80 rounded-xl p-5 space-y-4">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <Code2 className="w-4.5 h-4.5 text-indigo-500" />
                      Инструкция к API
                    </h4>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      {workflow.step3_script.scriptExplanation}
                    </p>
                    <div className="p-3.5 bg-white border border-slate-200 rounded-lg space-y-2">
                      <p className="text-[10px] font-bold text-slate-500 uppercase">Эндпоинт отправки:</p>
                      <code className="text-[10px] block p-2 bg-slate-100 rounded-md font-mono text-indigo-600">
                        https://api.ideav.ru/v1/_d_new
                      </code>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Interface Templates (HTML/JS) */}
            {currentStep === 4 && (
              <div className="space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-slate-800 mb-1">Этап 4: Шаблоны интерфейса (HTML/JS)</h3>
                    <p className="text-xs text-slate-500">Автоматическая генерация адаптивных веб-интерфейсов для рабочих мест сотрудников.</p>
                  </div>

                  {/* Tab controllers */}
                  <div className="inline-flex bg-slate-100 p-1 rounded-xl">
                    <button
                      onClick={() => setActiveCodeTab("html")}
                      className={`px-3 py-1.5 text-xs font-bold rounded-lg cursor-pointer transition-all flex items-center gap-1.5 ${
                        activeCodeTab === "html" ? "bg-white text-slate-800 shadow-xs" : "text-slate-500 hover:text-slate-800"
                      }`}
                    >
                      <Layout className="w-3.5 h-3.5" />
                      HTML Шаблон
                    </button>
                    <button
                      onClick={() => setActiveCodeTab("js")}
                      className={`px-3 py-1.5 text-xs font-bold rounded-lg cursor-pointer transition-all flex items-center gap-1.5 ${
                        activeCodeTab === "js" ? "bg-white text-slate-800 shadow-xs" : "text-slate-500 hover:text-slate-800"
                      }`}
                    >
                      <FileCode className="w-3.5 h-3.5" />
                      JS Логика
                    </button>
                    <button
                      onClick={() => setActiveCodeTab("css")}
                      className={`px-3 py-1.5 text-xs font-bold rounded-lg cursor-pointer transition-all flex items-center gap-1.5 ${
                        activeCodeTab === "css" ? "bg-white text-slate-800 shadow-xs" : "text-slate-500 hover:text-slate-800"
                      }`}
                    >
                      <Code2 className="w-3.5 h-3.5" />
                      CSS Стили
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Left panel: Codes view */}
                  <div className="lg:col-span-7 space-y-2">
                    <div className="flex justify-between items-center text-[11px] text-slate-500 font-bold px-1">
                      <span>КОД ФАЙЛА ({activeCodeTab.toUpperCase()})</span>
                      <button
                        onClick={() => handleCopy(
                          activeCodeTab === "html" 
                            ? workflow.step4_templates.htmlCode 
                            : activeCodeTab === "js" 
                              ? workflow.step4_templates.jsCode 
                              : workflow.step4_templates.cssNotes,
                          "templates_code"
                        )}
                        className="inline-flex items-center gap-1 text-indigo-600 hover:text-indigo-800 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        {copiedText === "templates_code" ? "Копировано!" : "Копировать код"}
                      </button>
                    </div>

                    <div className="bg-slate-950 p-4 rounded-xl text-xs font-mono text-slate-200 border border-slate-800 h-[360px] overflow-y-auto leading-relaxed shadow-inner">
                      <pre>
                        {activeCodeTab === "html" && workflow.step4_templates.htmlCode}
                        {activeCodeTab === "js" && workflow.step4_templates.jsCode}
                        {activeCodeTab === "css" && workflow.step4_templates.cssNotes}
                      </pre>
                    </div>
                  </div>

                  {/* Right panel: Live workplace simulation */}
                  <div className="lg:col-span-5 flex flex-col justify-between border border-slate-200 rounded-2xl overflow-hidden bg-slate-50 shadow-sm h-[395px]">
                    <div className="bg-white border-b border-slate-200/80 px-4 py-2.5 flex justify-between items-center select-none shrink-0">
                      <span className="text-[10px] font-bold text-slate-600 flex items-center gap-1.5">
                        <Eye className="w-3.5 h-3.5 text-indigo-500" />
                        Интерактивный симулятор рабочего места
                      </span>
                      <span className="bg-emerald-100 text-emerald-800 text-[8px] font-extrabold px-1.5 py-0.5 rounded-sm">● LIVE PREVIEW</span>
                    </div>

                    {/* Workplace preview window */}
                    <div className="p-4 flex-1 overflow-y-auto flex flex-col justify-start">
                      <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-4 shadow-2xs">
                        <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                          <h4 className="font-bold text-xs text-indigo-600">{appName || "No-Code Приложение"}</h4>
                          <span className="text-[9px] text-slate-400">Роль: Менеджер</span>
                        </div>

                        {/* Simulated input form */}
                        <div className="space-y-2.5 text-[11px]">
                          <div>
                            <label className="block text-slate-400 font-medium mb-1">Выбрать Клиента (tclient_id)</label>
                            <select className="w-full p-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-700">
                              <option>Иванов Петр Сергеевич</option>
                              <option>Смирнова Ольга Игоревна</option>
                              <option>+ Создать нового...</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-slate-400 font-medium mb-1">Описание наряда (tdescription)</label>
                            <input type="text" value="Замена масла и фильтров Toyota" disabled className="w-full p-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-500" />
                          </div>
                          <div>
                            <label className="block text-slate-400 font-medium mb-1">Сумма заказа, руб. (tamount)</label>
                            <input type="text" value="4 500" disabled className="w-full p-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-500" />
                          </div>
                          <button className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-lg text-xs transition-colors cursor-pointer mt-1">
                            Сохранить запись
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-100 px-4 py-3 border-t border-slate-200 text-[10px] text-slate-500 leading-snug shrink-0">
                      📝 Форма биндит поля напрямую в БД Integram благодаря паттерну <code>t&#123;column_id&#125;</code> (например, <code>name=&quot;tclient_id&quot;</code>).
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 5: Roles and Permissions */}
            {currentStep === 5 && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-800 mb-1">Этап 5: Настройка прав доступа и меню</h3>
                  <p className="text-xs text-slate-500">Системные таблицы доступа <code>_roles</code>, <code>_menu</code>, <code>_users</code> и управление масками прав.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Roles list */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <ShieldCheck className="w-4.5 h-4.5 text-indigo-500" />
                      Ролевая структура в _roles
                    </h4>
                    <div className="space-y-2.5">
                      {workflow.step5_roles_permissions.roles.map((r, idx) => (
                        <div key={idx} className="p-4 border border-slate-200 rounded-xl space-y-1.5 bg-white hover:border-slate-300 transition-colors">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-xs text-slate-800">{r.name}</span>
                            <span className="font-mono text-[9px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                              Маска: {r.mask}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 leading-relaxed">{r.tablesAccess}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Menu items */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <Layout className="w-4.5 h-4.5 text-indigo-500" />
                      Рабочие разделы меню в _menu
                    </h4>
                    <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 space-y-2">
                      {workflow.step5_roles_permissions.menuItems.map((item, idx) => (
                        <div key={idx} className="flex items-center gap-3 p-2.5 bg-white border border-slate-100 rounded-lg text-xs font-semibold text-slate-700 shadow-2xs">
                          <span className="w-5 h-5 rounded-md bg-indigo-50 text-indigo-600 flex items-center justify-center text-[10px] font-bold">
                            #{idx + 1}
                          </span>
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Demo Users list */}
                  {workflow.step5_roles_permissions.demoUsers && workflow.step5_roles_permissions.demoUsers.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                        <Users className="w-4.5 h-4.5 text-indigo-500" />
                        Тестовые доступы в _users (Демонстрация)
                      </h4>
                      <div className="space-y-2.5">
                        {workflow.step5_roles_permissions.demoUsers.map((user, idx) => (
                          <div key={idx} className="p-4 border border-slate-200 rounded-xl bg-white hover:border-slate-300 transition-colors space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="font-bold text-xs text-slate-800">{user.role}</span>
                              <span className="text-[10px] text-slate-400 font-semibold">Demo #{idx + 1}</span>
                            </div>
                            <div className="bg-slate-50 p-2.5 rounded-lg text-xs space-y-1.5 font-mono text-slate-700">
                              <div className="flex items-center justify-between gap-1">
                                <span>Логин: <span className="font-semibold text-slate-900">{user.login}</span></span>
                                <button 
                                  onClick={() => handleCopy(user.login, `u_l_${idx}`)}
                                  className="text-[10px] text-indigo-600 hover:text-indigo-800 font-sans font-bold flex items-center gap-0.5 cursor-pointer"
                                >
                                  {copiedText === `u_l_${idx}` ? "ОК" : "Копировать"}
                                </button>
                              </div>
                              {user.password && (
                                <div className="flex items-center justify-between gap-1 border-t border-slate-200/60 pt-1.5">
                                  <span>Пароль: <span className="font-semibold text-indigo-600">{user.password}</span></span>
                                  <button 
                                    onClick={() => handleCopy(user.password || "", `u_p_${idx}`)}
                                    className="text-[10px] text-indigo-600 hover:text-indigo-800 font-sans font-bold flex items-center gap-0.5 cursor-pointer"
                                  >
                                    {copiedText === `u_p_${idx}` ? "ОК" : "Копировать"}
                                  </button>
                                </div>
                              )}
                            </div>
                            <p className="text-[10px] text-slate-500 leading-normal">{user.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Step 6: Test data seeding */}
            {currentStep === 6 && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-800 mb-1">Этап 6: Наполнение тестовыми данными</h3>
                  <p className="text-xs text-slate-500">Пакеты импорта первоначальных записей для проверки связи Lookups и автовычислений полей.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Seeding JSON code */}
                  <div className="lg:col-span-8 space-y-2">
                    <div className="flex justify-between items-center text-[11px] text-slate-500 font-bold px-1">
                      <span>JSON ПАКЕТ (POST _d_req)</span>
                      <button
                        onClick={() => handleCopy(workflow.step6_seeding.seedPayload, "seed_payload")}
                        className="inline-flex items-center gap-1 text-indigo-600 hover:text-indigo-800 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        {copiedText === "seed_payload" ? "Копировано!" : "Копировать код"}
                      </button>
                    </div>

                    <div className="bg-slate-950 p-4 rounded-xl text-xs font-mono text-slate-200 border border-slate-800 max-h-[350px] overflow-y-auto leading-relaxed shadow-inner">
                      <pre>{workflow.step6_seeding.seedPayload}</pre>
                    </div>
                  </div>

                  {/* Seed guide */}
                  <div className="lg:col-span-4 bg-slate-50 border border-slate-200/80 rounded-xl p-5 space-y-4">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <Briefcase className="w-4.5 h-4.5 text-indigo-500" />
                      Запуск загрузки
                    </h4>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      {workflow.step6_seeding.instructions}
                    </p>
                    <div className="p-3.5 bg-white border border-slate-200 rounded-lg space-y-2">
                      <p className="text-[10px] font-bold text-slate-500 uppercase">Эндпоинт отправки:</p>
                      <code className="text-[10px] block p-2 bg-slate-100 rounded-md font-mono text-indigo-600">
                        https://api.ideav.ru/v1/_d_req
                      </code>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Step 7: Verification and Launch */}
            {currentStep === 7 && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-800 mb-1">Этап 7: Проверка качества и запуск приложения</h3>
                  <p className="text-xs text-slate-500">Чек-лист сквозного тестирования функциональности до запуска приложения в эксплуатацию.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Verification checklist with toggles */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <CheckSquare className="w-4.5 h-4.5 text-indigo-500" />
                      Ручное функциональное тестирование
                    </h4>
                    <div className="space-y-2.5">
                      {workflow.step7_checklist.map((item, idx) => {
                        const isChecked = !!checkedItems[idx];
                        return (
                          <div 
                            key={idx} 
                            onClick={() => setCheckedItems(prev => ({ ...prev, [idx]: !prev[idx] }))}
                            className={`p-4 border rounded-xl flex items-start gap-3 transition-all cursor-pointer select-none ${
                              isChecked ? "border-emerald-500 bg-emerald-50/20 text-emerald-900" : "border-slate-200 bg-white text-slate-700 hover:border-slate-300"
                            }`}
                          >
                            <div className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                              isChecked ? "bg-emerald-600 border-emerald-600 text-white" : "border-slate-300 text-transparent"
                            }`}>
                              <Check className="w-3.5 h-3.5 font-bold" />
                            </div>
                            <span className="text-xs font-medium leading-relaxed">{item}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Launch CTA Panel */}
                  <div className="bg-linear-to-br from-indigo-950 via-slate-900 to-indigo-950 text-white border border-indigo-500/20 rounded-2xl p-6 flex flex-col justify-between shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none" />
                    
                    <div className="space-y-4 relative z-10">
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/20 text-indigo-300 rounded-full text-[10px] font-bold border border-indigo-400/20 uppercase tracking-wider">
                        Проверка завершена
                      </div>
                      <h4 className="font-extrabold text-base tracking-tight leading-tight">Ваше Low-Code приложение готово к релизу!</h4>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        Все системные таблицы, роли доступа и HTML-шаблоны созданы согласно спецификации CRM Integram. Вы можете выгрузить готовый проект и запустить его на облачной платформе прямо сейчас.
                      </p>
                    </div>

                    <div className="pt-6 space-y-3 relative z-10">
                      <button
                        onClick={() => setIsPublished(true)}
                        className="w-full inline-flex items-center justify-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3.5 rounded-xl text-xs shadow-lg hover:scale-101 transition-all cursor-pointer"
                      >
                        <Wand2 className="w-4 h-4" />
                        Опубликовать на ideav.ru
                      </button>
                      
                      <a
                        href="https://ideav.ru/excel-to-app.html"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full inline-flex items-center justify-center gap-1 text-slate-300 hover:text-white bg-slate-800/60 border border-slate-700/80 hover:bg-slate-800 py-3 rounded-xl text-xs font-semibold transition-colors"
                      >
                        Открыть Integram AI
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>

                {/* Simulated Platform Login & Workspace */}
                {(() => {
                  const activeTable = workflow.step2_schema?.tables?.find(t => t.id === simActiveTableId);
                  const activeTableRows = simTablesData[simActiveTableId] || [];
                  const filteredRows = activeTableRows.filter(row => {
                    if (!simSearchQuery.trim()) return true;
                    const query = simSearchQuery.toLowerCase();
                    return Object.values(row).some(val => 
                      String(val).toLowerCase().includes(query)
                    );
                  });

                  return (
                    <div className="border-t border-slate-200/80 pt-6 mt-6 space-y-6">
                      <div className="space-y-1">
                        <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                          <ShieldCheck className="w-5 h-5 text-indigo-600" />
                          Симулятор Платформы Integram AI (Прототип СУБД)
                        </h3>
                        <p className="text-xs text-slate-500">
                          Введите сгенерированные в Шаге #5 доступы в интеграм-симулятор ниже, чтобы запустить спроектированное приложение и поработать с СУБД в реальном времени под разными ролями!
                        </p>
                      </div>

                      {!simLoggedInUser ? (
                        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 max-w-2xl mx-auto space-y-6 shadow-xs">
                          <div className="flex items-center gap-3 border-b border-slate-200/60 pb-3">
                            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100">
                              <ShieldCheck className="w-5 h-5 text-indigo-600" />
                            </div>
                            <div>
                              <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wide">Вход в CRM: {appName || "Ваше Приложение"}</h4>
                              <p className="text-[10px] text-slate-400">Вход на платформу Integram</p>
                            </div>
                          </div>

                          {simLoginError && (
                            <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-xs text-red-700 flex items-start gap-2">
                              <span className="text-red-500 mt-0.5 font-bold">⚠️</span>
                              <span>{simLoginError}</span>
                            </div>
                          )}

                          <form onSubmit={handleSimLogin} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                              <label className="block text-[11px] font-bold text-slate-600 uppercase">Логин (Email)</label>
                              <input 
                                type="text" 
                                placeholder="admin@integram.local"
                                value={simLogin}
                                onChange={e => setSimLogin(e.target.value)}
                                className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:border-indigo-500 focus:outline-hidden bg-white"
                                required
                              />
                            </div>
                            <div className="space-y-1.5">
                              <label className="block text-[11px] font-bold text-slate-600 uppercase">Пароль</label>
                              <input 
                                type="password" 
                                placeholder="••••••••"
                                value={simPassword}
                                onChange={e => setSimPassword(e.target.value)}
                                className="w-full text-xs p-3 border border-slate-200 rounded-xl focus:border-indigo-500 focus:outline-hidden bg-white"
                                required
                              />
                            </div>

                            <div className="md:col-span-2 pt-2 flex flex-col sm:flex-row justify-between gap-4 items-center border-t border-slate-100 pt-4">
                              <div className="space-y-1.5 self-start">
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Быстрый клик для входа:</p>
                                <div className="flex flex-wrap gap-2">
                                  {workflow.step5_roles_permissions?.demoUsers?.map((u, uIdx) => (
                                    <button
                                      key={uIdx}
                                      type="button"
                                      onClick={() => handleQuickSimLogin(u)}
                                      className="px-2.5 py-1 bg-white hover:bg-indigo-50 hover:border-indigo-300 border border-slate-200 rounded-lg text-[10px] font-semibold text-slate-700 cursor-pointer transition-all"
                                    >
                                      {u.role} ({u.login})
                                    </button>
                                  ))}
                                </div>
                              </div>

                              <button
                                type="submit"
                                className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-xl text-xs shadow-md transition-colors cursor-pointer self-stretch sm:self-center"
                              >
                                Войти в Систему
                              </button>
                            </div>
                          </form>
                        </div>
                      ) : (
                        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs flex flex-col">
                          {/* Top bar */}
                          <div className="bg-slate-900 text-white px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                            <div className="space-y-1">
                              <h4 className="font-extrabold text-sm tracking-tight flex items-center gap-1.5">
                                <span className="text-emerald-400">●</span> {appName || "Ваша CRM"}
                              </h4>
                              <p className="text-[10px] text-slate-400">{appDesc || "Рабочий кабинет сотрудника"}</p>
                            </div>

                            <div className="flex flex-wrap items-center gap-3">
                              <div className="px-3 py-1 bg-slate-800 border border-slate-700 rounded-lg text-xs flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-indigo-400"></span>
                                <span className="text-slate-300">
                                  Вы вошли как: <strong className="text-white font-bold">{simLoggedInUser.role}</strong> ({simLoggedInUser.login})
                                </span>
                              </div>

                              <button
                                onClick={() => setSimLoggedInUser(null)}
                                className="px-3 py-1 bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white rounded-lg text-xs font-semibold border border-rose-500/30 transition-all cursor-pointer"
                              >
                                Выйти
                              </button>
                            </div>
                          </div>

                          {/* App Menu Navigation items bar */}
                          {workflow.step5_roles_permissions?.menuItems && workflow.step5_roles_permissions.menuItems.length > 0 && (
                            <div className="bg-slate-50 border-b border-slate-100 px-6 py-2.5 flex items-center gap-2 overflow-x-auto">
                              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider shrink-0 mr-1.5">Разделы меню:</span>
                              {workflow.step5_roles_permissions.menuItems.map((menuItem, mIdx) => (
                                <span 
                                  key={mIdx}
                                  className={`px-3 py-1 text-xs font-bold rounded-lg ${
                                    mIdx === 1 ? "bg-indigo-50 text-indigo-700 border border-indigo-100" : "text-slate-600 bg-white/60 border border-transparent"
                                  }`}
                                >
                                  {menuItem}
                                </span>
                              ))}
                            </div>
                          )}

                          {/* Workspace Metrics */}
                          <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4 border-b border-slate-100 bg-slate-50/20">
                            <div className="p-4 bg-white border border-slate-200/80 rounded-xl space-y-1.5 shadow-2xs">
                              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Всего записей в СУБД</span>
                              <div className="text-2xl font-black text-slate-800">{activeTableRows.length}</div>
                              <div className="text-[10px] text-emerald-600 font-medium">Активное хранилище Integram</div>
                            </div>

                            <div className="p-4 bg-white border border-slate-200/80 rounded-xl space-y-1.5 shadow-2xs">
                              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Общий объем / Показатели</span>
                              <div className="text-2xl font-black text-indigo-600">
                                {(() => {
                                  const amtCol = activeTable?.columns?.find(c => c.format === "t=num");
                                  if (amtCol) {
                                    const sum = activeTableRows.reduce((acc, row) => acc + (Number(row[amtCol.id]) || 0), 0);
                                    return `${sum.toLocaleString("ru-RU")} (по ${amtCol.name})`;
                                  }
                                  return `${activeTableRows.length} записей`;
                                })()}
                              </div>
                              <div className="text-[10px] text-slate-500 font-medium">Сумма по колонке типа t=num</div>
                            </div>

                            <div className="p-4 bg-white border border-slate-200/80 rounded-xl space-y-1.5 shadow-2xs">
                              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Статус и права доступа</span>
                              <div className="text-sm font-bold text-emerald-700 flex items-center gap-1.5 pt-0.5">
                                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                                Авторизован
                              </div>
                              <p className="text-[10px] text-slate-500 leading-tight">
                                Маска: <code className="bg-slate-100 px-1 py-0.5 rounded text-[9px] font-mono font-bold">{
                                  (workflow.step5_roles_permissions?.roles?.find(r => r.name === simLoggedInUser.role) || { mask: "WRITE, READ" }).mask
                                }</code>
                              </p>
                            </div>
                          </div>

                          {/* Main workspace interactive split */}
                          <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
                            {/* Table viewing list */}
                            <div className="lg:col-span-8 space-y-4">
                              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                                <div className="flex items-center gap-2">
                                  {workflow.step2_schema?.tables?.length > 1 ? (
                                    <select 
                                      value={simActiveTableId} 
                                      onChange={e => setSimActiveTableId(e.target.value)}
                                      className="text-xs font-bold text-slate-800 p-2 border border-slate-200 rounded-lg focus:outline-hidden bg-slate-50 cursor-pointer"
                                    >
                                      {workflow.step2_schema.tables.map(t => (
                                        <option key={t.id} value={t.id}>📋 {t.name} ({t.id})</option>
                                      ))}
                                    </select>
                                  ) : (
                                    <h5 className="font-bold text-xs text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                                      <Layout className="w-4 h-4 text-slate-400" />
                                      Таблица: {activeTable?.name || "Реестр Записей"}
                                    </h5>
                                  )}
                                </div>

                                <div className="relative w-full sm:w-64">
                                  <input 
                                    type="text"
                                    placeholder="Быстрый поиск по записям..."
                                    value={simSearchQuery}
                                    onChange={e => setSimSearchQuery(e.target.value)}
                                    className="w-full text-xs pl-8 pr-3 py-1.5 border border-slate-200 rounded-xl focus:border-indigo-500 focus:outline-hidden bg-slate-50/50"
                                  />
                                  <span className="absolute left-2.5 top-2.5 text-slate-400 text-xs">🔍</span>
                                </div>
                              </div>

                              <div className="border border-slate-200/85 rounded-xl overflow-hidden overflow-x-auto bg-white shadow-2xs">
                                <table className="w-full min-w-[500px]">
                                  <thead>
                                    <tr className="bg-slate-50/85 border-b border-slate-200 text-left">
                                      {activeTable?.columns?.map((col, cIdx) => (
                                        <th key={cIdx} className="px-4 py-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                                          {col.name}
                                        </th>
                                      ))}
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-slate-100">
                                    {filteredRows.length > 0 ? (
                                      filteredRows.map((row, rIdx) => (
                                        <tr key={rIdx} className="hover:bg-slate-50/30 transition-colors">
                                          {activeTable?.columns?.map((col, cIdx) => {
                                            const val = row[col.id];
                                            const isNum = col.format === "t=num";
                                            return (
                                              <td key={cIdx} className={`px-4 py-3 text-xs text-slate-700 ${isNum ? "font-mono font-bold text-indigo-600" : ""}`}>
                                                {isNum ? Number(val || 0).toLocaleString("ru-RU") : String(val ?? "")}
                                              </td>
                                            );
                                          })}
                                        </tr>
                                      ))
                                    ) : (
                                      <tr>
                                        <td colSpan={activeTable?.columns?.length || 1} className="px-4 py-8 text-center text-xs text-slate-400 font-medium">
                                          Записи не найдены. Создайте первую запись в форме справа!
                                        </td>
                                      </tr>
                                    )}
                                  </tbody>
                                </table>
                              </div>
                            </div>

                            {/* Record creation form */}
                            <div className="lg:col-span-4 bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">
                              {(() => {
                                const userRole = workflow?.step5_roles_permissions?.roles?.find(r => r.name === simLoggedInUser.role) || { mask: "WRITE, READ" };
                                const hasWrite = userRole.mask.includes("WRITE") || userRole.mask.includes("ADMIN");

                                if (!hasWrite) {
                                  return (
                                    <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2.5 text-amber-900">
                                      <div className="flex items-center gap-1.5 text-xs font-bold text-amber-800">
                                        <span>🚫</span> Доступ Ограничен
                                      </div>
                                      <p className="text-[11px] leading-relaxed">
                                        Ваша роль <strong>{simLoggedInUser.role}</strong> имеет права только на чтение базы данных (маска: <code>{userRole.mask}</code>).
                                      </p>
                                      <p className="text-[10px] text-slate-500 leading-normal">
                                        Вы можете выйти из системы и войти под учетной записью Руководителя/Администратора, чтобы добавлять новые записи.
                                      </p>
                                    </div>
                                  );
                                }

                                return (
                                  <form onSubmit={handleAddSimRow} className="space-y-4">
                                    <div className="border-b border-slate-200 pb-2.5">
                                      <h5 className="font-bold text-xs text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                                        <span>➕</span> Добавить запись
                                      </h5>
                                      <p className="text-[9px] text-slate-400 leading-normal">
                                        Автогенерация полей ввода для таблицы: {activeTable?.name}
                                      </p>
                                    </div>

                                    <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
                                      {activeTable?.columns?.map((col, cIdx) => (
                                        <div key={cIdx} className="space-y-1">
                                          <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wide">
                                            {col.name} {col.format === "t=num" && "(число)"}
                                          </label>
                                          <input 
                                            type={col.format === "t=num" ? "number" : col.format === "t=date" ? "date" : "text"}
                                            placeholder={`Введите ${col.name.toLowerCase()}...`}
                                            value={simNewRecord[col.id] || ""}
                                            onChange={e => setSimNewRecord(prev => ({ ...prev, [col.id]: e.target.value }))}
                                            className="w-full text-xs p-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 bg-white"
                                            required={col.format === "t=num" || col.format === "t=date"}
                                          />
                                        </div>
                                      ))}
                                    </div>

                                    <button 
                                      type="submit"
                                      className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-all cursor-pointer shadow-xs flex items-center justify-center gap-1.5"
                                    >
                                      <span>💾</span> Записать в СУБД
                                    </button>
                                  </form>
                                );
                              })()}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Celebration publishing Modal */}
      {isPublished && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 text-slate-800 space-y-5 relative shadow-2xl">
            <button
              onClick={() => setIsPublished(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 text-lg font-bold cursor-pointer"
            >
              &times;
            </button>

            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-xl font-bold animate-bounce">
                🎉
              </div>
              <h3 className="font-extrabold text-base text-slate-900">Поздравляем с запуском!</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Ваше Low-Code CRM приложение на базе Integram AI полностью спроектировано и готово к импорту.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl space-y-2.5 border border-slate-100 text-xs text-slate-600 leading-normal">
              <p>📌 <strong>Что делать дальше:</strong></p>
              <ul className="list-disc pl-5 space-y-1 text-[11px] text-slate-500">
                <li>Скопируйте структуры таблиц с Шага #3 и отправьте по API _d_new.</li>
                <li>Загрузите HTML и JS код Шага #4 в конструктор вашего рабочего места.</li>
                <li>Наполните базу демонстрационными данными по Шагу #6.</li>
              </ul>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                onClick={() => setIsPublished(false)}
                className="flex-1 py-3 text-xs font-bold text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                Вернуться
              </button>
              <a
                href="https://ideav.ru/excel-to-app.html"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-3 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl shadow-lg hover:scale-101 transition-all"
              >
                Войти в Integram
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
