import React, { useState } from "react";
import { 
  Wand2, 
  Sparkles, 
  Check, 
  ArrowRight, 
  Table, 
  Smartphone, 
  Zap, 
  Search, 
  LayoutGrid, 
  TrendingUp, 
  Lock,
  Globe
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function IntegramBanner() {
  const [activeStep, setActiveStep] = useState<1 | 2 | 3>(1);
  const [isDemoLaunched, setIsDemoLaunched] = useState(false);

  return (
    <div className="bg-linear-to-br from-slate-900 via-indigo-950 to-slate-950 rounded-2xl p-6 md:p-8 text-white border border-indigo-500/20 shadow-xl overflow-hidden relative">
      {/* Visual background details */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl -ml-20 -mb-20 pointer-events-none" />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
        {/* Left Column: Copywriting and CTA */}
        <div className="lg:col-span-7 space-y-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/20 text-indigo-300 rounded-full text-[10px] font-bold border border-indigo-400/20 uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            Интегрировано с Integram AI
          </div>

          <div className="space-y-3">
            <h2 className="text-xl md:text-2xl font-extrabold tracking-tight leading-tight">
              Сделайте из вашей Excel-таблицы полноценное <span className="text-indigo-400 bg-clip-text">веб-приложение за 45 минут</span>
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed max-w-xl">
              Integram AI — это революционная no-code платформа, которая автоматически распознает логику, формулы и структуру ваших Excel/CSV таблиц, преобразуя их в современные безопасные веб-интерфейсы с базой данных и API.
            </p>
          </div>

          {/* Bullet points of features */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {[
              { title: "Рабочий софт за 45 минут", desc: "Быстрее, чем составить ТЗ для программистов" },
              { title: "No-Code Конструктор", desc: "Просто перетаскивайте блоки форм и графиков" },
              { title: "Автоматический REST API", desc: "Уже встроенная СУБД со сквозным шифрованием" },
              { title: "Идеально для мобильных", desc: "Клиенты и сотрудники вводят данные со смартфонов" }
            ].map((f, idx) => (
              <div key={idx} className="flex items-start gap-2.5">
                <div className="p-1 bg-indigo-500/20 rounded-md text-indigo-400 shrink-0 mt-0.5">
                  <Check className="w-3 h-3 font-bold" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-100">{f.title}</h4>
                  <p className="text-[10px] text-slate-400">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Action buttons */}
          <div className="pt-4 flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => setIsDemoLaunched(true)}
              className="inline-flex items-center justify-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs px-5 py-3 shadow-md hover:scale-102 transition-all cursor-pointer"
            >
              <Wand2 className="w-4 h-4" />
              Запустить симулятор сборки
            </button>
            <a
              href="https://ideav.ru/excel-to-app.html"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-1.5 text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded-xl text-xs px-5 py-3 transition-colors"
            >
              Перейти на Integram AI
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Right Column: Step-by-step Interactive Simulator */}
        <div className="lg:col-span-5">
          <div className="bg-slate-900/95 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
            {/* Window header */}
            <div className="bg-slate-800/80 px-4 py-3 flex items-center justify-between border-b border-slate-800/60 text-[10px] text-slate-400 select-none">
              <span className="font-semibold flex items-center gap-1.5 text-slate-300">
                <Globe className="w-3.5 h-3.5 text-indigo-400" />
                симулятор_integram_ai.exe
              </span>
              <div className="flex gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-700" />
                <span className="w-2.5 h-2.5 rounded-full bg-slate-700" />
                <span className="w-2.5 h-2.5 rounded-full bg-slate-700" />
              </div>
            </div>

            {/* Stepper progress indicator */}
            <div className="grid grid-cols-3 border-b border-slate-800 text-[10px] text-slate-400 text-center">
              {[
                { step: 1, label: "1. Анализ Excel" },
                { step: 2, label: "2. Сборка СУБД" },
                { step: 3, label: "3. Готовый Web-App" }
              ].map(s => (
                <button
                  key={s.step}
                  onClick={() => setActiveStep(s.step as any)}
                  className={`py-2 px-1 transition-colors border-b-2 cursor-pointer font-bold ${activeStep === s.step ? "border-indigo-500 bg-indigo-500/5 text-indigo-400" : "border-transparent hover:bg-slate-800 text-slate-500"}`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {/* Content area based on step */}
            <div className="p-5 h-64 flex flex-col justify-between">
              <AnimatePresence mode="wait">
                {activeStep === 1 && (
                  <motion.div
                    key="step1"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="space-y-4"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-green-500/10 rounded-xl text-green-400">
                        <Table className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-slate-100">Импорт структуры Excel листа</h4>
                        <p className="text-[10px] text-slate-400">Считывание заголовков, типов данных и формул</p>
                      </div>
                    </div>

                    {/* Simulation file parser graphic */}
                    <div className="bg-slate-950 p-3 rounded-lg font-mono text-[9px] text-slate-400 border border-slate-800/50 space-y-1">
                      <p className="text-emerald-400 flex items-center gap-1.5">
                        <Check className="w-3 h-3" /> Файл "отчет_продаж.xlsx" загружен
                      </p>
                      <p>• Найдено колонок: 6 (Товар, Цена, Кол-во, Итог...)</p>
                      <p>• Найдено формул: 2 (=B2*C2, =SUM(E2:E10))</p>
                      <p className="text-indigo-400 font-bold animate-pulse">→ Расчет типов данных выполнен автоматически</p>
                    </div>

                    <button
                      onClick={() => setActiveStep(2)}
                      className="w-full inline-flex items-center justify-center gap-1.5 text-[10px] font-bold text-white bg-slate-800 hover:bg-slate-700 py-2 rounded-lg cursor-pointer"
                    >
                      Перейти к шагу 2
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </motion.div>
                )}

                {activeStep === 2 && (
                  <motion.div
                    key="step2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="space-y-4"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-indigo-500/10 rounded-xl text-indigo-400">
                        <Zap className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-slate-100">Инициализация базы данных и API</h4>
                        <p className="text-[10px] text-slate-400">ИИ разворачивает облачный бэкенд и шифрование</p>
                      </div>
                    </div>

                    {/* Database flow mock */}
                    <div className="bg-slate-950 p-3 rounded-lg font-mono text-[9px] text-slate-400 border border-slate-800/50 space-y-1">
                      <p className="text-indigo-400">1. Создание таблицы SQL ... <span className="text-emerald-400">успешно</span></p>
                      <p className="text-indigo-400">2. Генерация защищенного REST API ... <span className="text-emerald-400">успешно</span></p>
                      <p className="text-slate-500">// Доступные эндпоинты: GET /api/v1/orders, POST /api/v1/orders</p>
                      <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                        <div className="bg-indigo-500 h-full w-4/5 animate-pulse" />
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveStep(3)}
                      className="w-full inline-flex items-center justify-center gap-1.5 text-[10px] font-bold text-white bg-indigo-600 hover:bg-indigo-500 py-2 rounded-lg cursor-pointer"
                    >
                      Собрать Веб-Интерфейс
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </motion.div>
                )}

                {activeStep === 3 && (
                  <motion.div
                    key="step3"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="space-y-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-400">
                        <Smartphone className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-slate-100">Приложение успешно запущено!</h4>
                        <p className="text-[9px] text-slate-400">Адаптивный дашборд с авторизацией готов</p>
                      </div>
                    </div>

                    {/* Interactive mock web-app dashboard render */}
                    <div className="bg-white p-2.5 rounded-lg border border-slate-200/10 space-y-2 text-slate-800 shadow-lg">
                      <div className="flex items-center justify-between border-b border-slate-100 pb-1.5 text-[9px] font-bold">
                        <span className="text-indigo-600">Отдел Продаж App</span>
                        <span className="bg-green-100 text-green-700 px-1.5 rounded-sm text-[8px]">● LIVE</span>
                      </div>
                      
                      <div className="relative">
                        <Search className="absolute left-1.5 top-1/2 -translate-y-1/2 text-slate-400 w-2.5 h-2.5" />
                        <div className="w-full pl-5 pr-2 py-0.5 bg-slate-100 rounded-sm text-[8px] text-slate-400 select-none">
                          Поиск товаров...
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-1.5 text-[8px]">
                        <div className="p-1.5 bg-slate-50 rounded-sm border border-slate-100">
                          <p className="text-slate-400">Ноутбук Pro</p>
                          <p className="font-bold text-slate-800">75 000 руб.</p>
                        </div>
                        <div className="p-1.5 bg-slate-50 rounded-sm border border-slate-100">
                          <p className="text-slate-400">Клавиатура RGB</p>
                          <p className="font-bold text-slate-800">4 500 руб.</p>
                        </div>
                      </div>
                    </div>

                    <div className="text-[9px] text-center text-emerald-400 font-semibold animate-bounce">
                      🚀 Сборка завершена за 45 минут!
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      {/* Simulator Modal overlay for immersive fun */}
      {isDemoLaunched && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 text-white space-y-6 relative shadow-2xl">
            <button
              onClick={() => setIsDemoLaunched(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg font-bold cursor-pointer"
            >
              &times;
            </button>

            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center mx-auto text-xl font-extrabold animate-pulse">
                💡
              </div>
              <h3 className="font-bold text-base">Интеграция Integram AI завершена!</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Вы убедились, как просто превратить плоский файл Excel в живое мобильное приложение без программирования.
              </p>
            </div>

            <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-3 text-xs leading-relaxed">
              <p>📍 <strong className="text-indigo-400">Что произошло за кулисами:</strong></p>
              <ul className="list-disc pl-5 space-y-1 text-slate-300 text-[11px]">
                <li>ИИ структурировал ваши столбцы в реляционную схему СУБД;</li>
                <li>Формулы вычислений автоматически превратились в серверные функции;</li>
                <li>Сгенерированы защищенные веб-формы ввода для удаленных сотрудников.</li>
              </ul>
            </div>

            <div className="flex gap-2.5">
              <button
                onClick={() => setIsDemoLaunched(false)}
                className="flex-1 py-3 text-xs font-bold text-slate-400 hover:text-white bg-slate-800 rounded-xl transition-colors cursor-pointer"
              >
                Вернуться к утилитам
              </button>
              <a
                href="https://ideav.ru/excel-to-app.html"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-3 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl shadow-lg hover:scale-102 transition-all"
              >
                Начать на платформе
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
