import React, { useState, useEffect, useRef } from "react";
import * as XLSX from "xlsx";
import { jsPDF } from "jspdf";
import "jspdf-autotable";
import { 
  Table, 
  Plus, 
  Trash2, 
  Bold, 
  Italic, 
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  Download, 
  Upload, 
  RotateCcw, 
  Sparkles, 
  HelpCircle,
  Wand2,
  TableProperties
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { SheetCell, SheetState } from "../types";

// Helper to convert index to Column Name (0 -> A, 1 -> B, 27 -> AB)
const getColName = (idx: number): string => {
  let name = "";
  let temp = idx;
  while (temp >= 0) {
    name = String.fromCharCode((temp % 26) + 65) + name;
    temp = Math.floor(temp / 26) - 1;
  }
  return name;
};

// Helper to parse Column Name to index (A -> 0, B -> 1, AB -> 27)
const parseColName = (name: string): number => {
  let idx = 0;
  for (let i = 0; i < name.length; i++) {
    idx = idx * 26 + (name.charCodeAt(i) - 64);
  }
  return idx - 1;
};

// Default template data
const DEFAULT_COLS = ["A", "B", "C", "D", "E", "F"];
const DEFAULT_ROWS: SheetCell[][] = [
  [
    { value: "Товар", style: { bold: true, align: "center", bg: "bg-slate-100" } },
    { value: "Цена за ед.", style: { bold: true, align: "center", bg: "bg-slate-100" } },
    { value: "Количество", style: { bold: true, align: "center", bg: "bg-slate-100" } },
    { value: "Налог %", style: { bold: true, align: "center", bg: "bg-slate-100" } },
    { value: "Итого (Чистое)", style: { bold: true, align: "center", bg: "bg-slate-100" } },
    { value: "Итого с Налогом", style: { bold: true, align: "center", bg: "bg-slate-100" } }
  ],
  [
    { value: "Ноутбук Pro", style: { align: "left" } },
    { value: "75000", style: { align: "right" } },
    { value: "2", style: { align: "right" } },
    { value: "20", style: { align: "right" } },
    { value: "=B2*C2", style: { align: "right", bold: true } },
    { value: "=E2*(1+D2/100)", style: { align: "right", bg: "bg-emerald-50", bold: true } }
  ],
  [
    { value: "Клавиатура Mech", style: { align: "left" } },
    { value: "4500", style: { align: "right" } },
    { value: "10", style: { align: "right" } },
    { value: "10", style: { align: "right" } },
    { value: "=B3*C3", style: { align: "right", bold: true } },
    { value: "=E3*(1+D3/100)", style: { align: "right", bg: "bg-emerald-50", bold: true } }
  ],
  [
    { value: "Мышь RGB", style: { align: "left" } },
    { value: "1800", style: { align: "right" } },
    { value: "5", style: { align: "right" } },
    { value: "20", style: { align: "right" } },
    { value: "=B4*C4", style: { align: "right", bold: true } },
    { value: "=E4*(1+D4/100)", style: { align: "right", bg: "bg-emerald-50", bold: true } }
  ],
  [
    { value: "Итого продаж:", style: { bold: true, align: "left", bg: "bg-slate-50" } },
    { value: "", style: { bg: "bg-slate-50" } },
    { value: "=SUM(C2:C4)", style: { align: "right", bold: true, bg: "bg-amber-50" } },
    { value: "", style: { bg: "bg-slate-50" } },
    { value: "=SUM(E2:E4)", style: { align: "right", bold: true, bg: "bg-amber-50" } },
    { value: "=SUM(F2:F4)", style: { align: "right", bold: true, bg: "bg-teal-50" } }
  ]
];

interface SpreadsheetProps {
  onLoadIntegram: (columns: string[], rows: string[][]) => void;
  overrideData?: { columns: string[]; rows: string[][] } | null;
  onClearOverride?: () => void;
}

export default function Spreadsheet({ onLoadIntegram, overrideData, onClearOverride }: SpreadsheetProps) {
  const [sheet, setSheet] = useState<SheetState>({
    columns: DEFAULT_COLS,
    rows: DEFAULT_ROWS,
    activeCell: { r: 1, c: 1 }
  });

  const [editValue, setEditValue] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Apply override data (e.g. from SEO Articles or OCR parser)
  useEffect(() => {
    if (overrideData) {
      const { columns, rows } = overrideData;
      
      // Pad columns with alphabetical names if we have more columns than headers
      const headerNames = columns.map((col, idx) => col || getColName(idx));
      
      const newRows: SheetCell[][] = rows.map(row => 
        row.map(cellValue => ({
          value: cellValue,
          style: { align: isNaN(Number(cellValue)) ? "left" : "right" }
        }))
      );

      // Add a header row
      const firstRow: SheetCell[] = headerNames.map(col => ({
        value: col,
        style: { bold: true, align: "center", bg: "bg-slate-100" }
      }));

      setSheet({
        columns: headerNames.map((_, i) => getColName(i)),
        rows: [firstRow, ...newRows],
        activeCell: { r: 1, c: 0 }
      });

      if (onClearOverride) onClearOverride();
    }
  }, [overrideData]);

  // Set formula/value in standard inputs
  useEffect(() => {
    if (sheet.activeCell) {
      const cell = sheet.rows[sheet.activeCell.r]?.[sheet.activeCell.c];
      setEditValue(cell?.value || "");
    } else {
      setEditValue("");
    }
  }, [sheet.activeCell, sheet.rows]);

  // Evaluates formula or returns original value
  const evaluateCell = (val: string, rIndex: number, cIndex: number, visited = new Set<string>()): string => {
    if (!val || typeof val !== "string") return val || "";
    if (!val.startsWith("=")) return val;

    const cellKey = `${rIndex},${cIndex}`;
    if (visited.has(cellKey)) return "#REF!"; // Circular dependency protection
    visited.add(cellKey);

    try {
      const formula = val.substring(1).trim();
      const upperFormula = formula.toUpperCase();

      // Helper to fetch cell value by coordinates
      const getCellValue = (colLetter: string, rowNumStr: string): number => {
        const cIdx = parseColName(colLetter);
        const rIdx = parseInt(rowNumStr, 10) - 1; // 1-indexed to 0-indexed
        
        const targetCell = sheet.rows[rIdx]?.[cIdx];
        if (!targetCell) return 0;
        
        const evaluated = evaluateCell(targetCell.value, rIdx, cIdx, new Set(visited));
        const num = parseFloat(evaluated);
        return isNaN(num) ? 0 : num;
      };

      // Helper to fetch string from cell
      const getCellString = (colLetter: string, rowNumStr: string): string => {
        const cIdx = parseColName(colLetter);
        const rIdx = parseInt(rowNumStr, 10) - 1;
        const targetCell = sheet.rows[rIdx]?.[cIdx];
        if (!targetCell) return "";
        return evaluateCell(targetCell.value, rIdx, cIdx, new Set(visited));
      };

      // 1. SUM function: SUM(C2:C4)
      if (upperFormula.startsWith("SUM(")) {
        const match = upperFormula.match(/SUM\(([A-Z]+)(\d+):([A-Z]+)(\d+)\)/);
        if (match) {
          const startCol = match[1];
          const startRow = parseInt(match[2], 10);
          const endCol = match[3];
          const endRow = parseInt(match[4], 10);

          let sum = 0;
          const scIdx = parseColName(startCol);
          const ecIdx = parseColName(endCol);
          const srIdx = startRow - 1;
          const erIdx = endRow - 1;

          for (let r = Math.min(srIdx, erIdx); r <= Math.max(srIdx, erIdx); r++) {
            for (let c = Math.min(scIdx, ecIdx); c <= Math.max(scIdx, ecIdx); c++) {
              const cellVal = sheet.rows[r]?.[c]?.value || "";
              const evalVal = parseFloat(evaluateCell(cellVal, r, c, new Set(visited)));
              if (!isNaN(evalVal)) sum += evalVal;
            }
          }
          return sum.toString();
        }
      }

      // 2. AVERAGE function: AVERAGE(C2:C4)
      if (upperFormula.startsWith("AVERAGE(")) {
        const match = upperFormula.match(/AVERAGE\(([A-Z]+)(\d+):([A-Z]+)(\d+)\)/);
        if (match) {
          const startCol = match[1];
          const startRow = parseInt(match[2], 10);
          const endCol = match[3];
          const endRow = parseInt(match[4], 10);

          let sum = 0;
          let count = 0;
          const scIdx = parseColName(startCol);
          const ecIdx = parseColName(endCol);
          const srIdx = startRow - 1;
          const erIdx = endRow - 1;

          for (let r = Math.min(srIdx, erIdx); r <= Math.max(srIdx, erIdx); r++) {
            for (let c = Math.min(scIdx, ecIdx); c <= Math.max(scIdx, ecIdx); c++) {
              const cellVal = sheet.rows[r]?.[c]?.value || "";
              const evalVal = parseFloat(evaluateCell(cellVal, r, c, new Set(visited)));
              if (!isNaN(evalVal)) {
                sum += evalVal;
                count++;
              }
            }
          }
          return count > 0 ? (sum / count).toFixed(2) : "0";
        }
      }

      // 3. UPPER function: UPPER(A2)
      if (upperFormula.startsWith("UPPER(")) {
        const match = upperFormula.match(/UPPER\(([A-Z]+)(\d+)\)/);
        if (match) {
          const str = getCellString(match[1], match[2]);
          return str.toUpperCase();
        }
      }

      // 4. LOWER function: LOWER(A2)
      if (upperFormula.startsWith("LOWER(")) {
        const match = upperFormula.match(/LOWER\(([A-Z]+)(\d+)\)/);
        if (match) {
          const str = getCellString(match[1], match[2]);
          return str.toLowerCase();
        }
      }

      // 5. Basic Arithmetic: A2*B2, A1+B2, A1-B2, A1/B2, etc. Or percentage like E2*(1+D2/100)
      // We will parse cell references using regex and evaluate them dynamically
      let parsedExp = formula;
      const refRegex = /([A-Z]+)(\d+)/g;
      let refMatch;
      let hasRefs = false;

      // Replace references e.g., B2 -> getCellValue("B", "2")
      while ((refMatch = refRegex.exec(formula)) !== null) {
        hasRefs = true;
        const col = refMatch[1];
        const row = refMatch[2];
        const val = getCellValue(col, row);
        parsedExp = parsedExp.replace(refMatch[0], val.toString());
      }

      // If it's a simple mathematical formula (allow digits, basic math symbols, dots, parentheses)
      if (/^[0-9+\-*/().\s]+$/.test(parsedExp)) {
        // Safe evaluation of mathematical expressions
        const result = new Function(`return ${parsedExp}`)();
        return isNaN(result) ? "#VALUE!" : Number(result).toString();
      }

      return val; // Return raw value if not standard formula
    } catch (e) {
      console.error("Formula eval error:", e);
      return "#ERROR!";
    }
  };

  const handleCellClick = (r: number, c: number) => {
    setSheet(prev => ({
      ...prev,
      activeCell: { r, c }
    }));
  };

  const handleCellChange = (r: number, c: number, value: string) => {
    setSheet(prev => {
      const newRows = prev.rows.map((row, rIdx) => 
        row.map((cell, cIdx) => {
          if (rIdx === r && cIdx === c) {
            return { ...cell, value };
          }
          return cell;
        })
      );
      return { ...prev, rows: newRows };
    });
  };

  const handleStyleChange = (key: "bold" | "italic" | "align" | "bg", val: any) => {
    if (!sheet.activeCell) return;
    const { r, c } = sheet.activeCell;

    setSheet(prev => {
      const newRows = prev.rows.map((row, rIdx) => 
        row.map((cell, cIdx) => {
          if (rIdx === r && cIdx === c) {
            const currentStyle = cell.style || {};
            let updatedStyle = { ...currentStyle };
            if (key === "bold") updatedStyle.bold = !currentStyle.bold;
            if (key === "italic") updatedStyle.italic = !currentStyle.italic;
            if (key === "align") updatedStyle.align = val;
            if (key === "bg") updatedStyle.bg = val;
            return { ...cell, style: updatedStyle };
          }
          return cell;
        })
      );
      return { ...prev, rows: newRows };
    });
  };

  const handleAddRow = () => {
    setSheet(prev => {
      const colCount = prev.columns.length;
      const newRow: SheetCell[] = Array(colCount).fill(null).map(() => ({ value: "" }));
      return {
        ...prev,
        rows: [...prev.rows, newRow]
      };
    });
  };

  const handleAddColumn = () => {
    setSheet(prev => {
      const newColName = getColName(prev.columns.length);
      const newRows = prev.rows.map(row => [...row, { value: "" }]);
      return {
        ...prev,
        columns: [...prev.columns, newColName],
        rows: newRows
      };
    });
  };

  const handleDeleteRow = () => {
    if (!sheet.activeCell || sheet.rows.length <= 1) return;
    const activeR = sheet.activeCell.r;
    setSheet(prev => {
      const newRows = prev.rows.filter((_, idx) => idx !== activeR);
      return {
        ...prev,
        rows: newRows,
        activeCell: { r: Math.max(0, activeR - 1), c: prev.activeCell!.c }
      };
    });
  };

  const handleDeleteColumn = () => {
    if (!sheet.activeCell || sheet.columns.length <= 1) return;
    const activeC = sheet.activeCell.c;
    setSheet(prev => {
      const newCols = prev.columns.slice(0, -1);
      const newRows = prev.rows.map(row => row.filter((_, idx) => idx !== activeC));
      return {
        ...prev,
        columns: newCols,
        rows: newRows,
        activeCell: { r: prev.activeCell!.r, c: Math.max(0, activeC - 1) }
      };
    });
  };

  const handleReset = () => {
    setSheet({
      columns: DEFAULT_COLS,
      rows: DEFAULT_ROWS,
      activeCell: { r: 1, c: 1 }
    });
  };

  // Import File (Excel/CSV/JSON) via SheetJS
  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const workbook = XLSX.read(bstr, { type: "binary" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        
        // Convert to array of arrays
        const data = XLSX.utils.sheet_to_json<string[]>(worksheet, { header: 1 });
        
        if (data.length === 0) return;

        // Determine column count
        const maxCols = Math.max(...data.map(row => row.length));
        const columns = Array(maxCols).fill(null).map((_, i) => getColName(i));

        const newRows: SheetCell[][] = data.map(row => {
          const cells: SheetCell[] = Array(maxCols).fill(null).map((_, i) => {
            const val = row[i] !== undefined ? String(row[i]) : "";
            return {
              value: val,
              style: { align: isNaN(Number(val)) ? "left" : "right" }
            };
          });
          return cells;
        });

        setSheet({
          columns,
          rows: newRows,
          activeCell: { r: 0, c: 0 }
        });
      } catch (err) {
        alert("Ошибка при чтении файла. Убедитесь, что формат корректен.");
      }
    };
    reader.readAsBinaryString(file);
  };

  // Export spreadsheet using SheetJS
  const handleExport = (format: "xlsx" | "csv" | "json") => {
    const rawData = sheet.rows.map((row, rIdx) => 
      row.map((cell, cIdx) => evaluateCell(cell.value, rIdx, cIdx))
    );

    if (format === "json") {
      // Build a neat JSON structure
      const headers = rawData[0] || [];
      const jsonObj = rawData.slice(1).map(row => {
        const item: Record<string, string> = {};
        headers.forEach((header, idx) => {
          item[header || `Column_${idx + 1}`] = row[idx] || "";
        });
        return item;
      });
      
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(jsonObj, null, 2));
      const downloadAnchor = document.createElement("a");
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `integram_sheet_${Date.now()}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      return;
    }

    const ws = XLSX.utils.aoa_to_sheet(rawData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");

    if (format === "xlsx") {
      XLSX.writeFile(wb, `integram_sheet_${Date.now()}.xlsx`);
    } else if (format === "csv") {
      XLSX.writeFile(wb, `integram_sheet_${Date.now()}.csv`, { bookType: "csv" });
    }
  };

  // Export to PDF via jsPDF AutoTable
  const handleExportPDF = () => {
    const doc = new jsPDF({ orientation: "landscape" });
    
    // Header
    doc.setFontSize(16);
    doc.setTextColor(33, 43, 54);
    doc.text("Integram AI - Автоматизированный Отчет", 14, 15);
    doc.setFontSize(10);
    doc.setTextColor(100, 110, 120);
    doc.text(`Сгенерировано в реальном времени: ${new Date().toLocaleString()}`, 14, 22);

    const bodyData = sheet.rows.map((row, rIdx) => 
      row.map((cell, cIdx) => evaluateCell(cell.value, rIdx, cIdx))
    );

    const headers = bodyData[0] || [];
    const tableData = bodyData.slice(1);

    (doc as any).autoTable({
      head: [headers],
      body: tableData,
      startY: 28,
      theme: "striped",
      headStyles: { fillColor: [79, 70, 229] }, // Bright premium purple / blue
      styles: { fontSize: 9, cellPadding: 3 },
    });

    doc.save(`integram_report_${Date.now()}.pdf`);
  };

  const getActiveCellStyle = () => {
    if (!sheet.activeCell) return null;
    return sheet.rows[sheet.activeCell.r]?.[sheet.activeCell.c]?.style || {};
  };

  const activeStyle = getActiveCellStyle();

  return (
    <div id="spreadsheet-container" className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Top Utility Bar */}
      <div className="bg-slate-50 border-b border-slate-200 p-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
            <TableProperties className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-800 text-base flex items-center gap-1.5">
              Умный табличный редактор
              <span className="text-[10px] bg-indigo-100 text-indigo-700 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                Google Sheets PRO
              </span>
            </h3>
            <p className="text-xs text-slate-500">
              Вводите формулы (=SUM, =AVERAGE, =B2*C2), форматируйте текст и импортируйте файлы
            </p>
          </div>
        </div>

        {/* Global Import/Export Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            accept=".xlsx, .xls, .csv, .json" 
            className="hidden" 
          />
          <button
            onClick={handleImportClick}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 transition-colors cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" />
            Импорт файла
          </button>

          {/* Export dropdown */}
          <div className="relative group">
            <button className="inline-flex items-center gap-1.5 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg px-3 py-2 transition-colors cursor-pointer">
              <Download className="w-3.5 h-3.5" />
              Экспорт отчета
            </button>
            <div className="absolute right-0 mt-1 w-44 bg-white border border-slate-200 rounded-lg shadow-lg py-1 z-50 hidden group-hover:block hover:block">
              <button 
                onClick={() => handleExport("xlsx")}
                className="w-full text-left px-4 py-2 text-xs hover:bg-slate-50 text-slate-700 flex items-center gap-2"
              >
                <span className="w-2 h-2 rounded-full bg-green-500" /> Excel (.xlsx)
              </button>
              <button 
                onClick={() => handleExport("csv")}
                className="w-full text-left px-4 py-2 text-xs hover:bg-slate-50 text-slate-700 flex items-center gap-2"
              >
                <span className="w-2 h-2 rounded-full bg-blue-500" /> Таблица (.csv)
              </button>
              <button 
                onClick={() => handleExport("json")}
                className="w-full text-left px-4 py-2 text-xs hover:bg-slate-50 text-slate-700 flex items-center gap-2"
              >
                <span className="w-2 h-2 rounded-full bg-yellow-500" /> Схема (.json)
              </button>
              <button 
                onClick={handleExportPDF}
                className="w-full text-left px-4 py-2 text-xs hover:bg-slate-50 text-slate-700 flex items-center gap-2 border-t border-slate-100"
              >
                <span className="w-2 h-2 rounded-full bg-red-500" /> Отчет PDF (.pdf)
              </button>
            </div>
          </div>

          <button
            onClick={handleReset}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            title="Сбросить таблицу"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Editor & Format toolbar */}
      <div className="border-b border-slate-200 p-3 bg-slate-50/50 flex flex-col md:flex-row gap-3 items-center">
        {/* Formatting actions */}
        <div className="flex items-center gap-1.5 border-r border-slate-200 pr-3 mr-1">
          <button
            onClick={() => handleStyleChange("bold", null)}
            className={`p-2 rounded-md transition-colors cursor-pointer ${activeStyle?.bold ? "bg-indigo-100 text-indigo-700" : "text-slate-600 hover:bg-slate-100"}`}
            title="Полужирный"
          >
            <Bold className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleStyleChange("italic", null)}
            className={`p-2 rounded-md transition-colors cursor-pointer ${activeStyle?.italic ? "bg-indigo-100 text-indigo-700" : "text-slate-600 hover:bg-slate-100"}`}
            title="Курсив"
          >
            <Italic className="w-4 h-4" />
          </button>
          
          <div className="h-4 w-px bg-slate-300 mx-1" />

          <button
            onClick={() => handleStyleChange("align", "left")}
            className={`p-2 rounded-md transition-colors cursor-pointer ${activeStyle?.align === "left" ? "bg-indigo-100 text-indigo-700" : "text-slate-600 hover:bg-slate-100"}`}
            title="Выравнивание влево"
          >
            <AlignLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleStyleChange("align", "center")}
            className={`p-2 rounded-md transition-colors cursor-pointer ${activeStyle?.align === "center" ? "bg-indigo-100 text-indigo-700" : "text-slate-600 hover:bg-slate-100"}`}
            title="По центру"
          >
            <AlignCenter className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleStyleChange("align", "right")}
            className={`p-2 rounded-md transition-colors cursor-pointer ${activeStyle?.align === "right" ? "bg-indigo-100 text-indigo-700" : "text-slate-600 hover:bg-slate-100"}`}
            title="Выравнивание вправо"
          >
            <AlignRight className="w-4 h-4" />
          </button>

          <div className="h-4 w-px bg-slate-300 mx-1" />

          {/* Color pickers */}
          <div className="flex items-center gap-1">
            {[
              { class: "bg-white border border-slate-300", value: "bg-white" },
              { class: "bg-slate-100", value: "bg-slate-100" },
              { class: "bg-yellow-50", value: "bg-yellow-50" },
              { class: "bg-emerald-50", value: "bg-emerald-50" },
              { class: "bg-indigo-50", value: "bg-indigo-50" },
              { class: "bg-rose-50", value: "bg-rose-50" },
              { class: "bg-amber-50", value: "bg-amber-50" }
            ].map(color => (
              <button
                key={color.value}
                onClick={() => handleStyleChange("bg", color.value)}
                className={`w-5 h-5 rounded-md cursor-pointer transition-transform hover:scale-110 ${color.class} ${activeStyle?.bg === color.value ? "ring-2 ring-indigo-600" : ""}`}
              />
            ))}
          </div>
        </div>

        {/* Formula Input Bar */}
        <div className="flex-1 w-full flex items-center gap-2">
          <span className="font-mono text-sm font-bold text-slate-400 select-none">fx</span>
          <input
            type="text"
            value={editValue}
            onChange={(e) => {
              setEditValue(e.target.value);
              if (sheet.activeCell) {
                handleCellChange(sheet.activeCell.r, sheet.activeCell.c, e.target.value);
              }
            }}
            placeholder="Введите значение или формулу (например, =B2*C2 или =SUM(C2:C4))"
            className="flex-1 min-w-0 px-3 py-1.5 text-sm font-mono bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
          />
        </div>

        {/* Row/Col Alteration buttons */}
        <div className="flex items-center gap-1">
          <button
            onClick={handleAddRow}
            className="inline-flex items-center gap-1 text-xs text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> +Строка
          </button>
          <button
            onClick={handleAddColumn}
            className="inline-flex items-center gap-1 text-xs text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" /> +Столбец
          </button>
          <button
            onClick={handleDeleteRow}
            disabled={!sheet.activeCell}
            className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
            title="Удалить выбранную строку"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleDeleteColumn}
            disabled={!sheet.activeCell}
            className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
            title="Удалить выбранный столбец"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Grid View */}
      <div className="overflow-x-auto max-h-[420px] overflow-y-auto">
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="bg-slate-100 text-slate-600 text-xs font-semibold select-none border-b border-slate-200">
              <th className="w-10 px-2 py-1.5 text-center border-r border-slate-200 bg-slate-200 sticky left-0 z-20"></th>
              {sheet.columns.map((colName, cIdx) => (
                <th key={colName} className="min-w-32 px-3 py-1.5 text-center border-r border-slate-200">
                  {colName}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sheet.rows.map((row, rIdx) => (
              <tr key={rIdx} className="hover:bg-slate-50/40 border-b border-slate-100">
                {/* Row Index Column */}
                <td className="px-2 py-1 bg-slate-100 text-slate-500 font-mono text-xs text-center border-r border-slate-200 sticky left-0 z-10 font-bold">
                  {rIdx + 1}
                </td>
                {/* Cell Columns */}
                {row.map((cell, cIdx) => {
                  const isActive = sheet.activeCell?.r === rIdx && sheet.activeCell?.c === cIdx;
                  const computedVal = evaluateCell(cell.value, rIdx, cIdx);
                  const alignment = cell.style?.align || "left";
                  const isFormula = cell.value && cell.value.startsWith("=");

                  return (
                    <td
                      key={cIdx}
                      onClick={() => handleCellClick(rIdx, cIdx)}
                      className={`relative min-w-32 h-9 p-0 border-r border-slate-100 transition-shadow ${cell.style?.bg || "bg-white"} ${isActive ? "ring-2 ring-indigo-600 ring-inset z-10" : ""}`}
                    >
                      <input
                        type="text"
                        value={isActive ? cell.value : computedVal}
                        onChange={(e) => handleCellChange(rIdx, cIdx, e.target.value)}
                        className={`w-full h-full px-2.5 py-1 focus:outline-hidden border-none text-slate-800 ${cell.style?.bold ? "font-bold" : ""} ${cell.style?.italic ? "italic" : ""} ${alignment === "left" ? "text-left" : alignment === "right" ? "text-right" : "text-center"} ${isFormula && !isActive ? "text-indigo-600 font-semibold bg-indigo-50/10 cursor-pointer" : ""}`}
                        style={{ background: "transparent" }}
                      />
                      {isFormula && !isActive && (
                        <div 
                          className="absolute right-1 top-1 w-1.5 h-1.5 bg-indigo-500 rounded-full" 
                          title="Вычисляемая ячейка (Формула)"
                        />
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Integram Promotional Banner footer in the spreadsheet */}
      <div className="bg-linear-to-r from-slate-900 to-indigo-950 p-4 text-white flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h4 className="font-semibold text-sm">Хотите больше автоматизации?</h4>
            <p className="text-xs text-slate-300">
              Сделайте из этой таблицы веб-приложение, панель мониторинга или API за 45 минут без кода!
            </p>
          </div>
        </div>
        <button
          onClick={() => {
            const cols = sheet.columns;
            const textRows = sheet.rows.map(row => row.map(cell => cell.value || ""));
            onLoadIntegram(cols, textRows);
          }}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-900 bg-white hover:bg-slate-100 rounded-xl px-4 py-2 transition-all cursor-pointer shadow-md hover:scale-102"
        >
          <Wand2 className="w-3.5 h-3.5 text-indigo-600" />
          Собрать веб-приложение
        </button>
      </div>
    </div>
  );
}
