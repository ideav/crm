import React, { useState } from "react";
import { 
  ShieldCheck, 
  RefreshCw, 
  Smartphone, 
  Laptop, 
  Tablet, 
  CheckCircle2, 
  AlertCircle,
  LogIn,
  LogOut,
  Chrome,
  KeyRound,
  User,
  Link
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { UserSession, SyncDevice } from "../types";

interface AuthSyncProps {
  session: UserSession;
  onLogin: (session: UserSession) => void;
  onLogout: () => void;
}

export default function AuthSync({ session, onLogin, onLogout }: AuthSyncProps) {
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncedTime, setLastSyncedTime] = useState<string>("5 минут назад");
  const [syncStatus, setSyncStatus] = useState<"idle" | "success" | "error">("idle");
  const [activeProvider, setActiveProvider] = useState<string | null>(null);

  // Hardcoded device list for sync demo
  const [devices, setDevices] = useState<SyncDevice[]>([
    { id: "1", name: "Этот браузер (Chrome Desktop)", type: "desktop", lastSync: "Только что", isCurrent: true },
    { id: "2", name: "iPhone 15 Pro Max", type: "mobile", lastSync: "10 минут назад", isCurrent: false },
    { id: "3", name: "iPad Pro 12.9\"", type: "tablet", lastSync: "1 час назад", isCurrent: false }
  ]);

  const handleSync = () => {
    setIsSyncing(true);
    setSyncStatus("idle");
    
    // Simulate real time socket or Cloud Sync
    setTimeout(() => {
      setIsSyncing(false);
      setSyncStatus("success");
      setLastSyncedTime("Только что");
      
      // Update all device times
      setDevices(prev => prev.map(d => ({
        ...d,
        lastSync: "Только что"
      })));

      setTimeout(() => setSyncStatus("idle"), 4000);
    }, 2000);
  };

  const simulateLogin = (provider: "google" | "vk" | "telegram" | "yandex") => {
    setActiveProvider(provider);
    
    setTimeout(() => {
      onLogin({
        isLoggedIn: true,
        userId: "usr_99831",
        name: provider === "google" ? "Дмитрий Верников" : "Дмитрий В.",
        email: provider === "google" ? "ideavrn@gmail.com" : "dmitry@integram.ai",
        avatar: provider === "google" 
          ? "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100" 
          : "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100",
        provider
      });
      setActiveProvider(null);
    }, 1200);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
      {/* Left Column: Authorization */}
      <div className="md:col-span-5 bg-slate-50/50 p-6 rounded-2xl border border-slate-200 flex flex-col justify-between">
        <div>
          <h4 className="font-semibold text-slate-800 text-sm mb-1.5 flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-indigo-600" />
            Личный кабинет и авторизация
          </h4>
          <p className="text-xs text-slate-500 mb-4 leading-relaxed">
            Авторизуйтесь, чтобы ваши таблицы, пресеты и настроенные конвертации мгновенно синхронизировались между всеми вашими устройствами.
          </p>

          <AnimatePresence mode="wait">
            {session.isLoggedIn ? (
              <motion.div
                key="logged-in"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="bg-white p-4 rounded-xl border border-indigo-100 shadow-2xs space-y-3"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={session.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100"}
                    alt="User avatar"
                    className="w-10 h-10 rounded-full border border-slate-200"
                  />
                  <div>
                    <h5 className="font-bold text-slate-800 text-xs">{session.name}</h5>
                    <p className="text-[10px] text-slate-400">{session.email}</p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] bg-slate-50 px-2.5 py-1.5 rounded-lg border border-slate-100">
                  <span className="text-slate-500">Авторизован через:</span>
                  <span className="font-bold text-indigo-600 uppercase">{session.provider}</span>
                </div>

                <button
                  onClick={onLogout}
                  className="w-full inline-flex items-center justify-center gap-1.5 text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100/80 rounded-lg py-2 transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Выйти из аккаунта
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="logged-out"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="space-y-2.5"
              >
                {/* Providers */}
                {[
                  { id: "google", name: "Войти через Google", color: "border-slate-200 text-slate-700 bg-white hover:bg-slate-50" },
                  { id: "telegram", name: "Войти через Telegram", color: "bg-[#229ED9] text-white border-transparent hover:bg-[#1e8ec3]" },
                  { id: "vk", name: "Войти через ВКонтакте", color: "bg-[#0077FF] text-white border-transparent hover:bg-[#006be5]" },
                  { id: "yandex", name: "Войти через Яндекс", color: "bg-[#FC3F1D] text-white border-transparent hover:bg-[#e23719]" }
                ].map(prov => (
                  <button
                    key={prov.id}
                    onClick={() => simulateLogin(prov.id as any)}
                    disabled={activeProvider !== null}
                    className={`w-full py-2.5 border rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${prov.color}`}
                  >
                    {activeProvider === prov.id ? (
                      <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <LogIn className="w-4 h-4" />
                    )}
                    {prov.name}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="mt-4 pt-4 border-t border-slate-200/60 flex items-center gap-2 text-[10px] text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>Безопасная сквозная авторизация по стандартам OAuth 2.0</span>
        </div>
      </div>

      {/* Right Column: Multi-Device Sync */}
      <div className="md:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 flex flex-col justify-between">
        <div>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
            <div>
              <h4 className="font-semibold text-slate-800 text-sm mb-0.5">Синхронизация устройств в реальном времени</h4>
              <p className="text-xs text-slate-400">Список ваших подключенных устройств и их статус</p>
            </div>
            
            <button
              onClick={handleSync}
              disabled={isSyncing}
              className={`inline-flex items-center gap-1.5 text-[10px] font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 px-3 py-1.5 rounded-lg cursor-pointer transition-all ${isSyncing ? "animate-pulse" : ""}`}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin" : ""}`} />
              {isSyncing ? "Синхронизация..." : "Синхронизировать"}
            </button>
          </div>

          {/* Sync active alerts */}
          {syncStatus === "success" && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-3 bg-emerald-50 border border-emerald-100 rounded-xl text-xs text-emerald-800 mb-4 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Синхронизация с облачным хранилищем Integram выполнена успешно!</span>
            </motion.div>
          )}

          {/* Devices Grid list */}
          <div className="space-y-2">
            {devices.map(device => (
              <div 
                key={device.id} 
                className={`p-3 border rounded-xl flex items-center justify-between transition-colors ${device.isCurrent ? "border-indigo-600 bg-indigo-50/10" : "border-slate-100 bg-slate-50/30"}`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${device.isCurrent ? "bg-indigo-100 text-indigo-700" : "bg-slate-100 text-slate-500"}`}>
                    {device.type === "desktop" && <Laptop className="w-4 h-4" />}
                    {device.type === "mobile" && <Smartphone className="w-4 h-4" />}
                    {device.type === "tablet" && <Tablet className="w-4 h-4" />}
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                      {device.name}
                      {device.isCurrent && (
                        <span className="text-[8px] font-bold uppercase tracking-wider bg-indigo-600 text-white px-1.5 py-0.5 rounded-md">
                          текущее
                        </span>
                      )}
                    </h5>
                    <p className="text-[10px] text-slate-400">Синхронизировано: {device.lastSync}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <div className={`w-2.5 h-2.5 rounded-full ${isSyncing ? "bg-indigo-500 animate-ping" : "bg-emerald-500"}`} />
                  <span className="text-[10px] text-slate-500 font-semibold">
                    {isSyncing ? "Обновление..." : "Онлайн"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p className="text-[10px] text-slate-400 mt-4 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
          <span className="font-semibold text-slate-700">О синхронизации:</span> Все ваши формулы, редактируемые данные и OCR выписки передаются по зашифрованному протоколу TLS. Начните работу на ПК и продолжайте со смартфона.
        </p>
      </div>
    </div>
  );
}
