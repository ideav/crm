import React, { useState } from "react";
import * as XLSX from "xlsx";
import { jsPDF } from "jspdf";
import "jspdf-autotable";
import { 
  FileSpreadsheet, 
  FileJson, 
  FileCode, 
  Sparkles, 
  Upload, 
  ArrowRight, 
  Check, 
  AlertCircle, 
  Camera, 
  Code, 
  Copy,
  FolderSync,
  Database,
  Grid,
  FileText
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ConvertersProps {
  onLoadParsedData: (data: { columns: string[]; rows: string[][] }) => void;
  activeSpreadsheetTab: () => void;
}

export default function Converters({ onLoadParsedData, activeSpreadsheetTab }: ConvertersProps) {
  const [activeTab, setActiveTab] = useState<"ocr" | "converters" | "api">("ocr");
  
  // OCR States
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isOcrLoading, setIsOcrLoading] = useState(false);
  const [ocrError, setOcrError] = useState<string | null>(null);
  const [ocrResult, setOcrResult] = useState<{ columns: string[]; rows: string[][] } | null>(null);

  // Converter States
  const [convFormat, setConvFormat] = useState<"excel-pdf" | "csv-excel" | "json-excel" | "excel-json" | "pdf-excel">("excel-pdf");
  const [convFile, setConvFile] = useState<File | null>(null);
  const [convSuccess, setConvSuccess] = useState(false);
  const [convLoading, setConvLoading] = useState(false);
  const [convError, setConvError] = useState<string | null>(null);
  const [jsonText, setJsonText] = useState("");
  const [pdfResult, setPdfResult] = useState<{ columns: string[]; rows: string[][] } | null>(null);

  // API states
  const [copiedCurl, setCopiedCurl] = useState(false);

  // OCR Presets to let users easily test the AI feature even if they don't have an image ready
  const OCR_PRESETS = [
    {
      name: "Отчет по продажам (Фото)",
      image: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&q=80&w=300",
      data: {
        columns: ["Товар", "Продавец", "Количество", "Цена", "Итого"],
        rows: [
          ["Планшет X", "Николай С.", "12", "34000", "408000"],
          ["Монитор 4K", "Ольга В.", "8", "28000", "224000"],
          ["Зарядка GaN", "Андрей К.", "45", "1900", "85500"],
          ["Чехол кожа", "Ольга В.", "30", "2500", "75000"]
        ]
      }
    },
    {
      name: "Штатное расписание",
      image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80&w=300",
      data: {
        columns: ["Сотрудник", "Департамент", "Ставка", "Стаж"],
        rows: [
          ["Смирнова А.В.", "HR", "90000", "2 года"],
          ["Волков Д.М.", "Разработка", "180000", "5 лет"],
          ["Кузнецова Е.А.", "Дизайн", "110000", "1 год"],
          ["Трофимов И.С.", "Продажи", "85000", "3 года"]
        ]
      }
    }
  ];

  // Load Preset directly for instant visual feedback
  const handleLoadPreset = (preset: typeof OCR_PRESETS[0]) => {
    setImagePreview(preset.image);
    setOcrResult(preset.data);
    setOcrError(null);
  };

  // Convert File to Base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64String = (reader.result as string).split(",")[1];
        resolve(base64String);
      };
      reader.onerror = error => reject(error);
    });
  };

  // Trigger real OCR request to our backend Gemini API
  const handleOcrSubmit = async () => {
    if (!imageFile) {
      setOcrError("Пожалуйста, сначала загрузите фотографию таблицы.");
      return;
    }

    setIsOcrLoading(true);
    setOcrError(null);
    setOcrResult(null);

    try {
      const base64Data = await fileToBase64(imageFile);
      const response = await fetch("/api/ocr", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          image: base64Data,
          mimeType: imageFile.type
        })
      });

      if (!response.ok) {
        throw new Error("Не удалось распознать таблицу. Сервер вернул ошибку.");
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setOcrResult({
        columns: data.columns || [],
        rows: data.rows || []
      });
    } catch (err: any) {
      console.error(err);
      setOcrError(err.message || "Ошибка соединения с ИИ-модулем.");
    } finally {
      setIsOcrLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setOcrResult(null);
      setOcrError(null);
    }
  };

  // Handle conversion of files
  const handleConvFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setConvFile(file);
      setConvSuccess(false);
      setConvError(null);
    }
  };

  const handleConvert = async () => {
    if (!convFile) {
      setConvError("Пожалуйста, выберите файл для конвертации.");
      return;
    }

    setConvLoading(true);
    setConvError(null);

    try {
      const reader = new FileReader();
      
      if (convFormat === "excel-pdf") {
        reader.onload = (evt) => {
          try {
            const bstr = evt.target?.result;
            const workbook = XLSX.read(bstr, { type: "binary" });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const rawData = XLSX.utils.sheet_to_json<string[]>(worksheet, { header: 1 });

            const doc = new jsPDF({ orientation: "landscape" });
            doc.text("Конвертированный Отчет Excel", 14, 15);
            
            (doc as any).autoTable({
              head: [rawData[0] || []],
              body: rawData.slice(1),
              startY: 22,
              theme: "grid"
            });
            doc.save("converted_excel.pdf");
            setConvSuccess(true);
          } catch (err) {
            setConvError("Не удалось сконвертировать Excel в PDF. Проверьте структуру файла.");
          } finally {
            setConvLoading(false);
          }
        };
        reader.readAsBinaryString(convFile);
      } 
      else if (convFormat === "csv-excel") {
        reader.onload = (evt) => {
          try {
            const text = evt.target?.result as string;
            // Parse CSV text to array of arrays
            const lines = text.split("\n").map(line => line.split(/[;,]/).map(cell => cell.trim()));
            const ws = XLSX.utils.aoa_to_sheet(lines);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
            XLSX.writeFile(wb, "converted_csv.xlsx");
            setConvSuccess(true);
          } catch (err) {
            setConvError("Неверная структура CSV-файла.");
          } finally {
            setConvLoading(false);
          }
        };
        reader.readAsText(convFile);
      }
      else if (convFormat === "json-excel") {
        reader.onload = (evt) => {
          try {
            const text = evt.target?.result as string;
            const jsonObj = JSON.parse(text);
            const ws = XLSX.utils.json_to_sheet(Array.isArray(jsonObj) ? jsonObj : [jsonObj]);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
            XLSX.writeFile(wb, "converted_json.xlsx");
            setConvSuccess(true);
          } catch (err) {
            setConvError("Неверный формат JSON.");
          } finally {
            setConvLoading(false);
          }
        };
        reader.readAsText(convFile);
      }
      else if (convFormat === "excel-json") {
        reader.onload = (evt) => {
          try {
            const bstr = evt.target?.result;
            const workbook = XLSX.read(bstr, { type: "binary" });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const data = XLSX.utils.sheet_to_json(worksheet);
            setJsonText(JSON.stringify(data, null, 2));
            setConvSuccess(true);
          } catch (err) {
            setConvError("Не удалось разобрать Excel-файл.");
          } finally {
            setConvLoading(false);
          }
        };
        reader.readAsBinaryString(convFile);
      }
      else if (convFormat === "pdf-excel") {
        try {
          const base64Data = await fileToBase64(convFile);
          const response = await fetch("/api/pdf-to-excel", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              file: base64Data,
              mimeType: "application/pdf"
            })
          });

          if (!response.ok) {
            throw new Error("Не удалось извлечь таблицу из PDF. Сервер вернул ошибку.");
          }

          const data = await response.json();
          if (data.error) {
            throw new Error(data.error);
          }

          setPdfResult({
            columns: data.columns || [],
            rows: data.rows || []
          });

          // Also trigger physical file download of .xlsx conversion of PDF!
          const ws = XLSX.utils.aoa_to_sheet([data.columns || [], ...(data.rows || [])]);
          const wb = XLSX.utils.book_new();
          XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
          XLSX.writeFile(wb, "converted_pdf_table.xlsx");

          setConvSuccess(true);
        } catch (err: any) {
          setConvError(err.message || "Ошибка соединения с ИИ-модулем извлечения PDF.");
        } finally {
          setConvLoading(false);
        }
      }
    } catch (err: any) {
      setConvError(err.message || "Ошибка конвертации.");
      setConvLoading(false);
    }
  };

  const handleCopyCurl = () => {
    const curl = `curl -X POST "https://api.integram.ai/v1/ocr" \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "image": "BASE64_IMAGE_DATA...",
    "mimeType": "image/jpeg"
  }'`;
    navigator.clipboard.writeText(curl);
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
      {/* Sub tabs */}
      <div className="flex border-b border-slate-200 bg-slate-50/50">
        {[
          { id: "ocr", label: "ИИ-Распознавание (OCR)", icon: Camera },
          { id: "converters", label: "Конвертеры файлов", icon: FolderSync },
          { id: "api", label: "API Интеграция", icon: Database }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-5 py-3.5 text-xs font-semibold border-b-2 transition-all cursor-pointer ${activeTab === tab.id ? "border-indigo-600 text-indigo-600 bg-white" : "border-transparent text-slate-500 hover:text-slate-800"}`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="p-6">
        <AnimatePresence mode="wait">
          {activeTab === "ocr" && (
            <motion.div
              key="ocr"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              transition={{ duration: 0.15 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6"
            >
              {/* Left Column: Input and Upload */}
              <div className="lg:col-span-5 flex flex-col gap-4">
                <div>
                  <h4 className="font-semibold text-slate-800 text-sm mb-1 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
                    Распознавание таблиц по фото
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Загрузите фотографию или скан таблицы (печатной или нарисованной от руки), и наш ИИ на базе Gemini мгновенно преобразует её в цифровой формат.
                  </p>
                </div>

                {/* Upload zone */}
                <div className="border-2 border-dashed border-slate-300 hover:border-indigo-500 bg-slate-50/30 rounded-xl p-6 transition-all text-center relative">
                  <input
                    type="file"
                    id="ocr-file-upload"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  {imagePreview ? (
                    <div className="space-y-3">
                      <img 
                        src={imagePreview} 
                        alt="Preview" 
                        className="max-h-40 mx-auto rounded-lg shadow-xs object-contain" 
                      />
                      <p className="text-xs text-slate-500 truncate">{imageFile?.name || "Изображение выбрано"}</p>
                      <button 
                        type="button" 
                        className="text-xs text-indigo-600 font-semibold underline hover:text-indigo-800"
                      >
                        Заменить фото
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="p-3 bg-white border border-slate-200 rounded-full w-12 h-12 flex items-center justify-center mx-auto text-slate-400">
                        <Upload className="w-5 h-5" />
                      </div>
                      <p className="text-xs font-semibold text-slate-700">Перетащите сюда фото или кликните</p>
                      <p className="text-[10px] text-slate-400">Поддерживаются PNG, JPG, JPEG до 10 МБ</p>
                    </div>
                  )}
                </div>

                {/* Try Presets */}
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-2">Нет фото под рукой? Попробуйте пресеты:</p>
                  <div className="flex gap-2">
                    {OCR_PRESETS.map((p, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleLoadPreset(p)}
                        className="flex-1 text-left p-2.5 border border-slate-200 hover:border-indigo-500 rounded-xl text-xs hover:bg-slate-50 transition-all cursor-pointer"
                      >
                        <p className="font-semibold text-slate-700 truncate">{p.name}</p>
                        <span className="text-[10px] text-indigo-600 font-bold">Загрузить демо</span>
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleOcrSubmit}
                  disabled={isOcrLoading}
                  className="w-full inline-flex items-center justify-center gap-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 rounded-xl py-3 shadow-xs transition-colors cursor-pointer"
                >
                  {isOcrLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Анализ таблицы нейросетью...
                    </>
                  ) : (
                    <>
                      <Camera className="w-4 h-4" />
                      Распознать таблицу на фото
                    </>
                  )}
                </button>

                {ocrError && (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-600 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                    <span>{ocrError}</span>
                  </div>
                )}
              </div>

              {/* Right Column: Output / Result */}
              <div className="lg:col-span-7 border-t lg:border-t-0 lg:border-l border-slate-100 pt-6 lg:pt-0 lg:pl-6 flex flex-col justify-between">
                <div>
                  <h4 className="font-semibold text-slate-800 text-sm mb-3 flex items-center gap-1.5">
                    <Grid className="w-4 h-4 text-slate-500" />
                    Результат распознавания табличных данных
                  </h4>

                  {ocrResult ? (
                    <div className="space-y-4">
                      {/* Interactive preview table of OCR */}
                      <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                        <div className="overflow-x-auto max-h-[240px]">
                          <table className="w-full text-left border-collapse">
                            <thead>
                              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                                {ocrResult.columns.map((col, idx) => (
                                  <th key={idx} className="p-2.5 border-r border-slate-200 whitespace-nowrap">
                                    {col}
                                  </th>
                                ))}
                              </tr>
                            </thead>
                            <tbody>
                              {ocrResult.rows.map((row, rIdx) => (
                                <tr key={rIdx} className="border-b border-slate-100 hover:bg-slate-50/50">
                                  {row.map((cell, cIdx) => (
                                    <td key={cIdx} className="p-2.5 border-r border-slate-100 text-slate-700">
                                      {cell}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>

                      <div className="p-3.5 bg-emerald-50 border border-emerald-100 rounded-xl text-xs text-emerald-800">
                        <span className="font-bold">Распознавание успешно выполнено!</span> Данные верифицированы и разложены по столбцам.
                      </div>
                    </div>
                  ) : (
                    <div className="h-60 border border-dashed border-slate-200 rounded-xl bg-slate-50/20 flex flex-col items-center justify-center text-slate-400 p-6 text-center">
                      <p className="text-xs">Результаты появятся здесь после загрузки изображения и активации анализа ИИ</p>
                      <span className="text-[10px] mt-1 text-slate-400">Или нажмите «Загрузить демо» ниже пресетов для проверки</span>
                    </div>
                  )}
                </div>

                {ocrResult && (
                  <div className="mt-4 pt-4 border-t border-slate-100 flex flex-col sm:flex-row gap-2">
                    <button
                      onClick={() => {
                        onLoadParsedData(ocrResult);
                        activeSpreadsheetTab();
                      }}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl py-2.5 transition-colors cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                      Импортировать в Редактор Таблиц
                    </button>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(JSON.stringify(ocrResult, null, 2));
                        alert("JSON скопирован в буфер обмена!");
                      }}
                      className="inline-flex items-center justify-center gap-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 transition-colors cursor-pointer"
                    >
                      Скопировать JSON
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "converters" && (
            <motion.div
              key="converters"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              transition={{ duration: 0.15 }}
              className="max-w-2xl mx-auto space-y-6"
            >
              <div>
                <h4 className="font-semibold text-slate-800 text-sm mb-1">Умные конвертеры табличных файлов</h4>
                <p className="text-xs text-slate-500">
                  Мгновенно преобразуйте файлы прямо в вашем браузере. Данные обрабатываются локально без загрузки на внешние серверы, гарантируя 100% конфиденциальность.
                </p>
              </div>

              {/* Selector */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {[
                  { id: "excel-pdf", label: "Excel в PDF", icon: FileSpreadsheet },
                  { id: "csv-excel", label: "CSV в Excel", icon: FileCode },
                  { id: "json-excel", label: "JSON в Excel", icon: FileJson },
                  { id: "excel-json", label: "Excel в JSON", icon: Code },
                  { id: "pdf-excel", label: "PDF в Excel (ИИ)", icon: FileText }
                ].map(format => (
                  <button
                    key={format.id}
                    onClick={() => {
                      setConvFormat(format.id as any);
                      setConvSuccess(false);
                      setConvError(null);
                      setConvFile(null);
                      setJsonText("");
                      setPdfResult(null);
                    }}
                    className={`p-2.5 border rounded-xl text-center flex flex-col items-center gap-1.5 transition-all cursor-pointer ${convFormat === format.id ? "border-indigo-600 bg-indigo-50/30 text-indigo-600 font-semibold" : "border-slate-200 hover:border-slate-300 text-slate-600"}`}
                  >
                    <format.icon className="w-5 h-5" />
                    <span className="text-[10px]">{format.label}</span>
                  </button>
                ))}
              </div>

              {/* File upload for converter */}
              <div className="space-y-4">
                <div className="border border-slate-200 rounded-xl p-6 bg-slate-50/50 flex flex-col items-center text-center relative">
                  <input
                    type="file"
                    onChange={handleConvFileChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <div className="p-2.5 bg-white border border-slate-200 rounded-full text-slate-400 mb-2">
                    <Upload className="w-5 h-5" />
                  </div>
                  <p className="text-xs font-semibold text-slate-700">
                    {convFile ? `Выбран файл: ${convFile.name}` : "Перетащите файл сюда или нажмите для выбора"}
                  </p>
                  <p className="text-[10px] text-slate-400 mt-1">
                    {convFormat === "excel-pdf" && "Поддерживаются файлы .xlsx, .xls до 10MB"}
                    {convFormat === "csv-excel" && "Поддерживаются файлы .csv до 10MB"}
                    {convFormat === "json-excel" && "Поддерживаются файлы .json до 10MB"}
                    {convFormat === "excel-json" && "Поддерживаются файлы .xlsx, .xls"}
                    {convFormat === "pdf-excel" && "Поддерживаются файлы .pdf (ИИ-распознавание структуры)"}
                  </p>
                </div>

                <button
                  onClick={handleConvert}
                  disabled={convLoading || !convFile}
                  className="w-full inline-flex items-center justify-center gap-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-100 disabled:text-slate-400 rounded-xl py-3 transition-colors cursor-pointer"
                >
                  {convLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Конвертация и сборка...
                    </>
                  ) : (
                    <>
                      Начать конвертацию
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>

                {convSuccess && (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-3">
                    <p className="text-xs text-emerald-800 font-semibold flex items-center gap-1.5">
                      <Check className="w-4 h-4" />
                      Конвертация успешно завершена! Файл сохранен на ваше устройство.
                    </p>
                    
                    {/* PDF Preview and Load */}
                    {pdfResult && (
                      <div className="space-y-3 mt-3 pt-3 border-t border-emerald-100">
                        <p className="text-[11px] font-bold text-slate-600">Распознанная таблица из PDF документа:</p>
                        <div className="border border-slate-200 rounded-lg overflow-hidden text-xs bg-white">
                          <div className="overflow-x-auto max-h-[160px]">
                            <table className="w-full text-left border-collapse">
                              <thead>
                                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[10px]">
                                  {pdfResult.columns.map((col, idx) => (
                                    <th key={idx} className="p-2 border-r border-slate-200 whitespace-nowrap">
                                      {col}
                                    </th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                {pdfResult.rows.map((row, rIdx) => (
                                  <tr key={rIdx} className="border-b border-slate-100 text-[10px] text-slate-700">
                                    {row.map((cell, cIdx) => (
                                      <td key={cIdx} className="p-2 border-r border-slate-100">
                                        {cell}
                                      </td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              onLoadParsedData(pdfResult);
                              activeSpreadsheetTab();
                            }}
                            className="flex-1 inline-flex items-center justify-center gap-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-lg text-xs cursor-pointer transition-colors"
                          >
                            <Grid className="w-3.5 h-3.5" />
                            Импортировать в Редактор Таблиц
                          </button>
                        </div>
                      </div>
                    )}

                    {jsonText && (
                      <div className="mt-3">
                        <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">Полученный JSON:</p>
                        <textarea
                          readOnly
                          value={jsonText}
                          className="w-full h-32 p-2 bg-slate-900 text-slate-100 rounded-lg text-[10px] font-mono focus:outline-hidden"
                        />
                      </div>
                    )}
                  </div>
                )}

                {convError && (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-600 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    <span>{convError}</span>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "api" && (
            <motion.div
              key="api"
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              transition={{ duration: 0.15 }}
              className="grid grid-cols-1 md:grid-cols-12 gap-6"
            >
              <div className="md:col-span-5 space-y-4">
                <div>
                  <h4 className="font-semibold text-slate-800 text-sm mb-1">Обработка таблиц по API в реальном времени</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Интегрируйте функционал распознавания и валидации Excel в вашу внутреннюю CRM, сайт или 1С. Скорость обработки составляет менее 1.5 секунд на документ.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="p-3 border border-slate-200 rounded-xl flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs">
                      1
                    </div>
                    <div>
                      <h5 className="font-semibold text-xs text-slate-800">Мгновенный ответ</h5>
                      <p className="text-[10px] text-slate-400">Формат JSON с автоопределением колонок</p>
                    </div>
                  </div>
                  <div className="p-3 border border-slate-200 rounded-xl flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs">
                      2
                    </div>
                    <div>
                      <h5 className="font-semibold text-xs text-slate-800">Полный REST API</h5>
                      <p className="text-[10px] text-slate-400">Легкая интеграция за 5 минут в любой стек</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="md:col-span-7 flex flex-col justify-between">
                <div className="bg-slate-900 rounded-xl overflow-hidden font-mono text-[11px] text-slate-200">
                  <div className="bg-slate-800 px-4 py-2 flex items-center justify-between border-b border-slate-700">
                    <span className="text-slate-400">cURL REST API запрос</span>
                    <button
                      onClick={handleCopyCurl}
                      className="text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
                    >
                      {copiedCurl ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Скопировано!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Скопировать</span>
                        </>
                      )}
                    </button>
                  </div>
                  <pre className="p-4 overflow-x-auto text-indigo-300">
                    {`curl -X POST "https://api.integram.ai/v1/ocr" \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "image": "BASE64_IMAGE_DATA...",
    "mimeType": "image/jpeg"
  }'`}
                  </pre>
                </div>

                <div className="mt-4 p-3.5 bg-indigo-50 border border-indigo-100 rounded-xl text-xs text-indigo-800">
                  <span className="font-bold">Бонус разработчикам:</span> С помощью Integram AI вы можете вообще не программировать API. Платформа делает все СУБД-привязки и создает готовый бэкенд на основе загруженного файла Excel автоматически.
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
