import express from "express";
import path from "path";
import { GoogleGenAI, Type } from "@google/genai";
import { dbOperations } from "./server/db";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Use JSON middleware with increased payload limit for image and PDF transfers
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Initialize Gemini client (will use process.env.GEMINI_API_KEY)
  const apiKey = process.env.GEMINI_API_KEY;
  let ai: GoogleGenAI | null = null;

  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  } else {
    console.warn("WARNING: GEMINI_API_KEY is not defined. OCR and PDF features will operate in demo/fallback mode.");
  }

  // Helper to query Gemini with sequential model fallback in case of rate limits (429) or transient server errors (503)
  async function generateWithFallback(
    aiClient: any,
    modelsOrder: string[],
    contents: any,
    config: any
  ): Promise<{ text: string; modelUsed: string }> {
    let lastError = null;
    for (const model of modelsOrder) {
      try {
        console.log(`[Gemini SafeClient] Attempting generation with model: ${model}...`);
        const response = await aiClient.models.generateContent({
          model: model,
          contents: contents,
          config: config,
        });
        if (response && response.text) {
          console.log(`[Gemini SafeClient] Generation succeeded with model: ${model}`);
          return { text: response.text, modelUsed: model };
        }
        throw new Error(`Empty response text from model ${model}`);
      } catch (err: any) {
        lastError = err;
        console.warn(`[Gemini SafeClient] Model ${model} failed: ${err.message || err}`);
      }
    }
    throw lastError || new Error("All model fallbacks failed");
  }

  // Health check API
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", mode: process.env.NODE_ENV || "development" });
  });

  // DB Logs endpoint
  app.get("/api/logs", (req, res) => {
    const logs = dbOperations.getLogs(100);
    res.json(logs);
  });

  // Authentication: Login or Register
  app.post("/api/auth/login", (req, res) => {
    const { email, name, avatar, provider } = req.body;
    if (!email || !provider) {
      return res.status(400).json({ error: "Missing email or provider" });
    }
    const user = dbOperations.getOrCreateUser({
      email,
      name: name || email.split("@")[0],
      avatar: avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100",
      provider
    });
    dbOperations.logEvent("auth_login", user.id, JSON.stringify(req.body).length, 5, "Successful authentication via " + provider);
    res.json({ success: true, user });
  });

  // Spreadsheets: Save Table with full encryption
  app.post("/api/spreadsheets/save", (req, res) => {
    const { userId, name, columns, rows } = req.body;
    if (!userId || !name || !columns || !rows) {
      return res.status(400).json({ error: "Missing required fields to save spreadsheet" });
    }
    const startTime = Date.now();
    try {
      const saved = dbOperations.saveSpreadsheet(userId, name, columns, rows);
      const duration = Date.now() - startTime;
      dbOperations.logEvent("save_spreadsheet", userId, JSON.stringify(rows).length, duration, `Encrypted save for: ${name}. Columns: ${columns.length}`);
      res.json({ success: true, saved });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to save spreadsheet", details: err.message });
    }
  });

  // Spreadsheets: List tables with full decryption
  app.get("/api/spreadsheets/list", (req, res) => {
    const { userId } = req.query;
    if (!userId) {
      return res.status(400).json({ error: "Missing userId parameter" });
    }
    try {
      const sheets = dbOperations.getSpreadsheetsByUser(userId as string);
      res.json(sheets);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to list spreadsheets", details: err.message });
    }
  });

  // Telegram bot chat endpoint
  app.post("/api/bot/chat", async (req, res) => {
    const { message, userId } = req.body;
    if (!message) {
      return res.status(400).json({ error: "Missing message parameter" });
    }
    const startTime = Date.now();

    try {
      if (!ai) {
        // High quality local response template fallback for Integram bot helper
        const lowerMsg = message.toLowerCase();
        let reply = "Привет! Я официальный бот Интеграм АИ. Моя цель — помочь вам оптимизировать Excel-таблицы и превратить их в веб-приложения за 45 минут!";
        
        if (lowerMsg.includes("привет") || lowerMsg.includes("здравствуй")) {
          reply = "Привет! Чем я могу помочь тебе сегодня в работе с Excel и Integram AI? 😊\n\nМогу подсказать формулу ВПР/СУММЕСЛИ, подсказать как загрузить PDF или как собрать первое приложение!";
        } else if (lowerMsg.includes("формул") || lowerMsg.includes("впр") || lowerMsg.includes("vlookup")) {
          reply = "Для поиска значения в таблице используйте формулу:\n`=ВПР(искомое_значение; таблица; номер_столбца; [интервальный_просмотр])`.\n\nВ английской версии: `=VLOOKUP(...)`.\nЕсли вам нужно объединить две таблицы, загрузите их в наш Редактор Таблиц, и вы сможете сделать это прямо в браузере!";
        } else if (lowerMsg.includes("pdf") || lowerMsg.includes("пдф")) {
          reply = "Чтобы извлечь данные из PDF в Excel, просто зайдите во вкладку «ИИ-Инструменты и Конвертеры», выберите тип «PDF в Excel» и загрузите ваш PDF-файл. Наша нейросеть Gemini 3.5 Flash автоматически распознает структуру и выведет готовую таблицу для редактирования!";
        } else if (lowerMsg.includes("приложен") || lowerMsg.includes("веб") || lowerMsg.includes("45")) {
          reply = "Это супер просто! Нажмите на баннер Интеграма внизу страницы. Наша no-code платформа анализирует логику Excel и мгновенно создает веб-формы ввода, API и готовую СУБД для ваших сотрудников и клиентов! Попробуйте прямо сейчас по ссылке: https://ideav.ru/excel-to-app.html";
        } else {
          reply = `Отличный вопрос! Я записал ваше сообщение: "${message}".\n\nДля того чтобы превратить этот запрос в ИИ-команду, убедитесь, что вы настроили GEMINI_API_KEY в настройках. Но даже без ключа вы можете использовать наш Редактор Таблиц онлайн, ИИ-конвертеры файлов и сохранять данные с шифрованием!`;
        }

        dbOperations.logEvent("bot_chat_fallback", userId, message.length, Date.now() - startTime, "Bot response fallback");
        return res.json({ reply });
      }

      const { text: replyText, modelUsed } = await generateWithFallback(
        ai,
        ["gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"],
        [
          {
            text: `User message: "${message}"`
          }
        ],
        {
          systemInstruction: "You are the official Telegram bot helper of Integram AI (@Integrammbot). Your goal is to help users with Excel spreadsheets, write complex Excel formulas (like VLOOKUP, SUMIFS, INDEX/MATCH), convert Excel to PDFs, and advise how to turn spreadsheets into custom web apps using Integram AI. Always respond in friendly Russian. Keep your advice practical, precise, and polite. Link to https://ideav.ru/excel-to-app.html when explaining how to convert sheets to apps.",
          temperature: 0.7
        }
      );

      const reply = replyText || "Извините, не удалось сформировать ответ. Попробуйте еще раз!";
      dbOperations.logEvent("bot_chat_gemini", userId, message.length, Date.now() - startTime, `Gemini generated chatbot response using ${modelUsed}`);
      res.json({ reply });

    } catch (err: any) {
      console.error("Bot chat error:", err);
      res.status(500).json({ error: "Failed to communicate with bot", details: err.message });
    }
  });

  // PDF to Excel API endpoint using Gemini 3.5 Flash
  app.post("/api/pdf-to-excel", async (req, res) => {
    const startTime = Date.now();
    try {
      const { file, mimeType, userId } = req.body;

      if (!file || !mimeType) {
        return res.status(400).json({ error: "Missing 'file' or 'mimeType' in request body." });
      }

      // Check if Gemini is available
      if (!ai) {
        console.log("Gemini API key is not set. Generating mock spreadsheet data from PDF for demo purposes...");
        // Return realistic mockup table data
        const demoData = {
          columns: ["Дата", "Артикул", "Наименование товара", "Кол-во", "Цена за шт (₽)", "Сумма (₽)"],
          rows: [
            ["01.06.2026", "A10923", "Смартфон Integram S1", "10", "45000", "450000"],
            ["03.06.2026", "B99281", "Беспроводные наушники Pro", "25", "5500", "137500"],
            ["10.06.2026", "C38192", "Зарядное устройство Type-C 65W", "50", "2200", "110000"],
            ["15.06.2026", "A88273", "Кабель силиконовый 1.5м", "120", "450", "54000"],
            ["20.06.2026", "D77211", "Чехол ультратонкий силикон", "80", "600", "48000"],
            ["Итого", "-", "-", "285", "-", "759500"]
          ],
          source: "demo-pdf-fallback"
        };
        dbOperations.logEvent("pdf_to_excel_fallback", userId, file.length, Date.now() - startTime, "Returned fallback mock data for PDF");
        return res.json(demoData);
      }

      console.log(`Sending PDF (${mimeType}) to Gemini with fallback logic for tabular data extraction...`);

      const { text: responseText, modelUsed } = await generateWithFallback(
        ai,
        ["gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"],
        [
          {
            inlineData: {
              mimeType: mimeType,
              data: file,
            },
          },
          {
            text: "Extract all tabular columns and grid lines from this PDF document. Identify the rows and columns accurately, keeping original names in Russian. Return a JSON object containing 'columns' (array of strings) and 'rows' (array of arrays of strings representing row values). Ensure columns line up precisely. If headers are missing, invent relevant columns.",
          }
        ],
        {
          systemInstruction: "You are an advanced financial and table-extraction engine. Your only job is to analyze the document, discover structural grids, and output structured JSON data conforming to the response schema. Handle all tables as standard columns and rows.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              columns: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Array of extracted column headers"
              },
              rows: {
                type: Type.ARRAY,
                items: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                description: "An array of rows, where each row contains cells corresponding to columns"
              }
            },
            required: ["columns", "rows"]
          }
        }
      );

      if (!responseText) {
        throw new Error("Empty response received from Gemini.");
      }

      let cleanText = responseText.trim();
      if (cleanText.startsWith("```")) {
        cleanText = cleanText.replace(/^```(?:json)?\n?/i, "").replace(/\n?```$/, "").trim();
      }

      const parsedData = JSON.parse(cleanText);
      const duration = Date.now() - startTime;
      dbOperations.logEvent("pdf_to_excel_success", userId, file.length, duration, "Gemini extracted " + parsedData.rows.length + " rows from PDF");
      res.json(parsedData);

    } catch (error: any) {
      console.error("Error in /api/pdf-to-excel route:", error);
      res.status(500).json({
        error: "Failed to extract table from PDF",
        details: error.message
      });
    }
  });

  // OCR Table parsing API using Gemini 3.5 Flash
  app.post("/api/ocr", async (req, res) => {
    const startTime = Date.now();
    const { image, mimeType, userId } = req.body;
    try {
      if (!image || !mimeType) {
        return res.status(400).json({ error: "Missing 'image' or 'mimeType' in request body." });
      }

      // Check if Gemini is available
      if (!ai) {
        console.log("Gemini API key is not set. Generating mock spreadsheet data for demo purposes...");
        // Return realistic mockup table data
        const demoData = {
          columns: ["ФИО", "Должность", "Департамент", "Оклад (руб)", "Стаж (лет)"],
          rows: [
            ["Иванов Иван", "Программист", "Разработка", "150000", "3"],
            ["Петров Петр", "Дизайнер", "Маркетинг", "120000", "2"],
            ["Сидоров Сидор", "Аналитик", "Продуктовый", "135000", "4"],
            ["Смирнова Анна", "HR-менеджер", "Персонал", "95000", "1"],
            ["Кузнецов Олег", "Тимлид", "Разработка", "250000", "7"]
          ],
          source: "demo-fallback"
        };
        dbOperations.logEvent("ocr_fallback", userId, image.length, Date.now() - startTime, "Returned fallback mock data for Image OCR");
        return res.json(demoData);
      }

      console.log(`Sending image (${mimeType}) to Gemini with fallback logic for table OCR...`);

      const { text: responseText, modelUsed } = await generateWithFallback(
        ai,
        ["gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"],
        [
          {
            inlineData: {
              mimeType: mimeType,
              data: image,
            },
          },
          {
            text: "Extract the table or grid from this image. Identify all rows and columns correctly, translating text to Russian if necessary, or keeping its original form. Return a list of columns and an array of rows (where each row is an array of cell values as strings). Formulate valid headers.",
          }
        ],
        {
          systemInstruction: "You are a professional OCR engine specializing in tabular data. Your only job is to extract tabular structures and output structured JSON data conforming to the response schema. If there are merged cells, split them and replicate values. If headers are absent, create logical column identifiers.",
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              columns: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Array of extracted column headers"
              },
              rows: {
                type: Type.ARRAY,
                items: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                description: "An array of rows, where each row contains cells corresponding to columns"
              }
            },
            required: ["columns", "rows"]
          }
        }
      );

      if (!responseText) {
        throw new Error("Empty response received from Gemini.");
      }

      let cleanText = responseText.trim();
      if (cleanText.startsWith("```")) {
        cleanText = cleanText.replace(/^```(?:json)?\n?/i, "").replace(/\n?```$/, "").trim();
      }

      const parsedData = JSON.parse(cleanText);
      const duration = Date.now() - startTime;
      dbOperations.logEvent("ocr_success", userId, image.length, duration, "Gemini extracted " + parsedData.rows.length + " rows from Image");
      res.json(parsedData);

    } catch (error: any) {
      console.error("Error in /api/ocr route:", error);
      res.status(500).json({
        error: "Failed to extract table from image",
        details: error.message
      });
    }
  });

  // Integram Low-Code Application Builder workflow generation endpoint
  app.post("/api/integram/generate-workflow", async (req, res) => {
    const { appName, description, spreadsheetColumns, spreadsheetRows } = req.body;
    const finalAppName = appName || "Умное Integram Приложение";
    const finalDesc = description || "Информационная no-code система, собранная на основе табличных данных.";

    console.log(`[Integram Builder] Generating workflow for app: "${finalAppName}"`);

    // fallback generator if Gemini is not initialized or fails
    const runFallback = () => {
      console.log(`[Integram Builder] Running dynamic custom fallback for "${finalAppName}"`);

      // Helper function to slugify column names
      const slugify = (text: string, idx: number): string => {
        const rusToEng: { [key: string]: string } = {
          "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "yo", "ж": "zh", "з": "z",
          "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r",
          "с": "s", "т": "t", "у": "u", "ф": "f", "х": "kh", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "shch",
          "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
          " ": "_"
        };
        let cleaned = text.toLowerCase().trim();
        let res = "";
        for (const char of cleaned) {
          if (rusToEng[char] !== undefined) {
            res += rusToEng[char];
          } else if (/[a-z0-9_-]/.test(char)) {
            res += char;
          }
        }
        res = res.replace(/_+/g, "_").replace(/^_+|_+$/g, "");
        return res || `col_${idx}`;
      };

      // Extract columns & rows or use default
      const cols = (spreadsheetColumns && spreadsheetColumns.length > 0) 
        ? spreadsheetColumns 
        : ["ФИО Клиента", "Компания", "Телефон", "Сумма Сделки", "Статус Сделки", "Дата Контакта", "Менеджер"];
      
      const rows = (spreadsheetRows && spreadsheetRows.length > 0)
        ? spreadsheetRows
        : [
            ["Иван Петров", "Вектор Плюс", "+7 (999) 111-22-33", "150000", "Новая заявка", "2026-06-25", "Иван Громов"],
            ["Елена Смирнова", "Смирнова ИП", "+7 (999) 555-66-77", "85000", "Согласование договора", "2026-06-24", "Анна Смирнова"]
          ];

      const mappedColumns = cols.map((col: string, idx: number) => {
        const id = slugify(col, idx);
        let format = "t=text";
        const lowerCol = col.toLowerCase();
        if (lowerCol.includes("сумма") || lowerCol.includes("цена") || lowerCol.includes("стоимость") || lowerCol.includes("бюджет") || lowerCol.includes("amount") || lowerCol.includes("price") || lowerCol.includes("sum") || lowerCol.includes("прогресс") || lowerCol.includes("число") || lowerCol.includes("номер")) {
          format = "t=num";
        } else if (lowerCol.includes("дата") || lowerCol.includes("день") || lowerCol.includes("срок") || lowerCol.includes("date") || lowerCol.includes("deadline")) {
          format = "t=date";
        }
        return { id, name: col, format };
      });

      // Business domain
      const businessDomain = `Автоматизация бизнес-процессов по направлению "${finalAppName}". Система разработана для ведения учета по колонкам: ${cols.join(", ")}.`;

      // Fields for API-script
      const dbFields: any = { "id": "t=text" };
      mappedColumns.forEach(c => {
        dbFields[c.id] = c.format;
      });

      // Seed payload
      const insert_records: any[] = [];
      rows.forEach((row: any[], rIdx: number) => {
        const record: any = { id: `r${rIdx + 1}` };
        mappedColumns.forEach((c, cIdx) => {
          let val: any = row[cIdx] || "";
          if (c.format === "t=num") {
            const num = parseFloat(String(val).replace(/[^0-9.-]/g, ""));
            val = isNaN(num) ? 0 : num;
          }
          record[c.id] = val;
        });
        insert_records.push(record);
      });

      const seedData = {
        "insert__roles": [
          { "id": "admin", "name": "Руководитель / Владелец", "mask": "WRITE, READ, ADMIN" },
          { "id": "manager", "name": "Оператор / Менеджер", "mask": "WRITE, READ" }
        ],
        "insert__users": [
          { "login": "admin@integram.local", "password_hash": "e10adc3949ba59abbe56e057f20f883e", "role_id": "admin", "name": "Иван Громов (Админ)" },
          { "login": "manager@integram.local", "password_hash": "21232f297a57a5a743894a0e4a801fc3", "role_id": "manager", "name": "Анна Смирнова (Менеджер)" }
        ],
        "insert__menu": [
          { "role_id": "admin", "title": "📊 Дашборд аналитики", "url": "/dashboard" },
          { "role_id": "admin", "title": "👥 База клиентов", "url": "/clients" },
          { "role_id": "admin", "title": "⚙️ Настройки доступа", "url": "/settings" },
          { "role_id": "manager", "title": "📝 Реестр Записей", "url": "/records" }
        ],
        "insert_crm_records": insert_records
      };

      const payloadJson = JSON.stringify({
        "_d_new": "crm_records",
        "fields": dbFields
      }, null, 2);

      // HTML Template
      const headersHtml = mappedColumns.map(c => `<th class="px-4 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">${c.name}</th>`).join("\n            ");
      const formFieldsHtml = mappedColumns.map(c => `
        <div class="space-y-1">
          <label class="block text-[11px] font-bold text-slate-500 uppercase tracking-wider">${c.name}</label>
          <input 
            type="${c.format === "t=num" ? "number" : c.format === "t=date" ? "date" : "text"}" 
            name="t${c.id}" 
            id="field_${c.id}" 
            placeholder="Введите ${c.name.toLowerCase()}..." 
            class="w-full text-xs p-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 bg-slate-50/50" 
          />
        </div>`).join("");

      const initialRowsHtml = insert_records.map(r => {
        const tds = mappedColumns.map(c => {
          const val = r[c.id];
          const isNum = c.format === "t=num";
          return `<td class="px-4 py-3.5 text-xs text-slate-700 ${isNum ? "font-mono font-bold text-indigo-600" : ""}">
            ${isNum ? Number(val).toLocaleString("ru-RU") : val}
          </td>`;
        }).join("\n            ");
        return `
          <tr class="hover:bg-slate-50/60 border-b border-slate-100 transition-colors">
            ${tds}
          </tr>`;
      }).join("");

      const htmlCode = `<!-- Шаблон Рабочего места для Integram CRM: ${finalAppName} -->
<div class="integram-workspace p-6 bg-slate-50/50 min-h-screen font-sans">
  <div class="max-w-7xl mx-auto space-y-6">
    
    <!-- Верхняя шапка -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs gap-4">
      <div class="space-y-1">
        <h2 class="text-base font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
          <span>💼</span> ${finalAppName}
        </h2>
        <p class="text-[11px] text-slate-500">${finalDesc}</p>
      </div>
      <div class="flex items-center gap-2">
        <span class="px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-100 text-[10px] font-bold rounded-full flex items-center gap-1">
          <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
          Active Cloud
        </span>
        <span class="px-2.5 py-1 bg-indigo-50 text-indigo-700 border border-indigo-100 text-[10px] font-bold rounded-full">
          Роль: Администратор
        </span>
      </div>
    </div>

    <!-- Показатели / Метрики -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div class="bg-white p-4 rounded-xl border border-slate-200/60 shadow-xs space-y-1.5">
        <span class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Всего записей</span>
        <div class="text-xl font-black text-slate-800" id="stats_total">${insert_records.length}</div>
        <div class="text-[10px] text-emerald-600 font-medium">Активное наполнение СУБД</div>
      </div>
      <div class="bg-white p-4 rounded-xl border border-slate-200/60 shadow-xs space-y-1.5">
        <span class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Общий объем сделок / сумм</span>
        <div class="text-xl font-black text-indigo-600" id="stats_amount">
          ${insert_records.reduce((acc, r) => {
            const amtCol = mappedColumns.find(c => c.format === "t=num");
            if (amtCol) return acc + (Number(r[amtCol.id]) || 0);
            return acc;
          }, 0).toLocaleString("ru-RU")}
        </div>
        <div class="text-[10px] text-slate-500 font-medium">По вычисляемым колонкам num</div>
      </div>
      <div class="bg-white p-4 rounded-xl border border-slate-200/60 shadow-xs space-y-1.5">
        <span class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Статус системы</span>
        <div class="text-xl font-black text-emerald-600">100% Онлайн</div>
        <div class="text-[10px] text-slate-500 font-medium">Автоматическая синхронизация Integram</div>
      </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      <!-- Список записей / Таблица -->
      <div class="lg:col-span-8 bg-white border border-slate-200/80 rounded-2xl shadow-xs overflow-hidden">
        <div class="p-4 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <h3 class="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <span>📋</span> Реестр СУБД
          </h3>
          <div class="relative w-full sm:w-64">
            <input 
              type="text" 
              id="searchInput" 
              placeholder="Поиск по таблице..." 
              class="w-full text-xs pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 bg-slate-50/30" 
            />
            <span class="absolute left-2.5 top-2 text-slate-400 text-xs">🔍</span>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full min-w-[700px]">
            <thead>
              <tr class="bg-slate-50/80 border-b border-slate-150">
                ${headersHtml}
              </tr>
            </thead>
            <tbody id="tableBody">
              ${initialRowsHtml}
            </tbody>
          </table>
        </div>
      </div>

      <!-- Форма быстрого добавления -->
      <div class="lg:col-span-4 bg-white border border-slate-200/80 rounded-2xl shadow-xs p-5 space-y-4">
        <div class="border-b border-slate-100 pb-3">
          <h3 class="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
            <span>➕</span> Быстрое Добавление
          </h3>
          <p class="text-[10px] text-slate-400 leading-normal">Поля ввода имеют имена t{column_id} для прямой привязки СУБД Integram.</p>
        </div>

        <form id="recordForm" class="space-y-4">
          ${formFieldsHtml}
          <button 
            type="submit" 
            class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs px-4 py-3 rounded-lg transition-colors cursor-pointer shadow-sm flex items-center justify-center gap-1.5"
          >
            <span>💾</span> Сохранить в СУБД
          </button>
        </form>
      </div>
    </div>

  </div>
</div>`;

      const jsCode = `// Integram low-code автоматизация и связывание полей
document.addEventListener("DOMContentLoaded", () => {
  console.log("Интеграция с Integram успешно инициализирована.");
  
  const searchInput = document.getElementById("searchInput");
  const tableBody = document.getElementById("tableBody");
  const recordForm = document.getElementById("recordForm");
  const statsTotal = document.getElementById("stats_total");
  const statsAmount = document.getElementById("stats_amount");

  const columnsMeta = ${JSON.stringify(mappedColumns)};

  // 1. Быстрый текстовый поиск по всем строкам таблицы
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      const q = e.target.value.toLowerCase();
      const rows = tableBody.querySelectorAll("tr");
      rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(q) ? "" : "none";
      });
    });
  }

  // 2. Обработка формы и добавление записи с пересчетом метрик
  if (recordForm) {
    recordForm.addEventListener("submit", (e) => {
      e.preventDefault();
      
      const formData = new FormData(recordForm);
      const newRowData = {};
      let hasValue = false;

      columnsMeta.forEach(col => {
        const val = formData.get("t" + col.id) || "";
        newRowData[col.id] = val;
        if (val) hasValue = true;
      });

      if (!hasValue) {
        alert("Пожалуйста, заполните хотя бы одно поле!");
        return;
      }

      // Создаем новую строку в таблице
      const tr = document.createElement("tr");
      tr.className = "hover:bg-slate-50/60 border-b border-slate-100 transition-colors";

      columnsMeta.forEach(col => {
        const td = document.createElement("td");
        const val = newRowData[col.id] || "";
        const isNum = col.format === "t=num";
        
        td.className = "px-4 py-3.5 text-xs text-slate-700" + (isNum ? " font-mono font-bold text-indigo-600" : "");
        if (isNum) {
          const num = parseFloat(String(val).replace(/[^0-9.-]/g, ""));
          td.textContent = isNaN(num) ? "0" : num.toLocaleString("ru-RU");
        } else {
          td.textContent = val;
        }
        tr.appendChild(td);
      });

      tableBody.appendChild(tr);

      // Сброс формы
      recordForm.reset();

      // Обновление метрик в реальном времени
      const allRows = tableBody.querySelectorAll("tr");
      if (statsTotal) {
        statsTotal.textContent = allRows.length;
      }

      // Пересчитываем общую сумму
      const amtCol = columnsMeta.find(c => c.format === "t=num");
      if (amtCol && statsAmount) {
        let sum = 0;
        allRows.forEach(row => {
          // Ищем ячейку по индексу колонки
          const colIdx = columnsMeta.indexOf(amtCol);
          const td = row.querySelectorAll("td")[colIdx];
          if (td) {
            const cleanText = td.textContent.replace(/\\s/g, "").replace(",", ".");
            const numVal = parseFloat(cleanText);
            if (!isNaN(numVal)) sum += numVal;
          }
        });
        statsAmount.textContent = sum.toLocaleString("ru-RU");
      }

      // AJAX-запрос эмуляции записи в СУБД Integram
      fetch("/_d_req", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "insert",
          table: "crm_records",
          row: newRowData
        })
      }).then(res => res.json())
        .then(data => console.log("Синхронизация Integram выполнена:", data))
        .catch(err => console.error("Синхронизация отклонена (Демо-режим):", err));
    });
  }
});`;

      const fallbackApp = {
        isFallback: true,
        step1_consolidation: {
          businessDomain,
          userJourneys: [
            {
              role: "Менеджер / Приемщик",
              journey: "Внесение и регистрация первичных данных",
              description: "Пользователь вводит данные в форму, они тут же попадают в СУБД с автоматическим пересчетом метрик."
            },
            {
              role: "Исполнитель / Мастер",
              journey: "Работа с назначенными записями",
              description: "Сотрудник фильтрует записи поиском, меняет статусы и оставляет комментарии."
            },
            {
              role: "Администратор / Аналитик",
              journey: "Анализ эффективности и экспорт данных",
              description: "Руководитель просматривает сводный дашборд с показателями объемов в рублях/количествах и управляет доступом."
            }
          ],
          requirementsChecklist: [
            "Возможность быстрого текстового поиска по ключевым полям",
            "Автоматическое вычисление итоговых сумм и счетчиков по строкам в реальном времени",
            "Разграничение прав: администратор видит финансовые итоги, оператор только вносит строки",
            "Адаптивность интерфейса под мобильные устройства и планшеты сотрудников"
          ]
        },
        step2_schema: {
          tables: [
            {
              id: "crm_records",
              name: "Реестр Записей CRM",
              columns: mappedColumns,
              relations: "Основная таблица для хранения бизнес-сущностей."
            }
          ]
        },
        step3_script: {
          payloadJson,
          scriptExplanation: "Инициализация структуры СУБД в Integram по API. Запросы отправляются методом POST на idempotent эндпоинт `_d_new` вашей базы данных для создания структуры таблиц и типизации полей."
        },
        step4_templates: {
          htmlCode,
          jsCode,
          cssNotes: "Используется стандартная интеграция со встроенным в платформу Integram UI фреймворком на базе классов Tailwind CSS. Дополнительная компиляция стилей на клиенте не требуется."
        },
        step5_roles_permissions: {
          roles: [
            { name: "Руководитель / Владелец", mask: "WRITE, READ, ADMIN", tablesAccess: "Полный доступ на чтение, запись и удаление всех таблиц СУБД, управление ролями." },
            { name: "Оператор / Менеджер", mask: "WRITE, READ", tablesAccess: "Разрешено добавлять клиентов и вносить новые записи. Изменение системных ролей запрещено." }
          ],
          menuItems: [
            "📊 Дашборд аналитики",
            "📝 Таблица записей",
            "👥 База клиентов",
            "⚙️ Настройки доступа"
          ],
          demoUsers: [
            { role: "Руководитель / Владелец", login: "admin@integram.local", password: "AdminPassword777", description: "Полный административный доступ к СУБД, панели управления, ролям и финансовым отчетам." },
            { role: "Оператор / Менеджер", login: "manager@integram.local", password: "ManagerPassword123", description: "Ограниченный доступ оператора для заведения заявок и справочника клиентов." }
          ]
        },
        step6_seeding: {
          seedPayload: JSON.stringify(seedData, null, 2),
          instructions: "Пакет с тестовыми данными отправляется на эндпоинт `_d_req` в формате JSON для безопасного наполнения базы демонстрационными сведениями до передачи рабочего места заказчику."
        },
        step7_checklist: [
          "Убедиться в уникальности ID таблиц и t=ref связей между ними",
          "Проверить права READ / WRITE для созданных ролей",
          "Проверить отображение созданных форм и меню на мобильных экранах",
          "Запустить сессию импорта реальных Excel-данных через конструктор"
        ]
      };
      res.json(fallbackApp);
    };

    if (!ai) {
      return runFallback();
    }

    try {
      const promptText = `Создай полноценный проект no-code веб-приложения для российской low-code СУБД Integram на основе следующих требований и данных:
Имя приложения: "${finalAppName}"
Описание бизнеса: "${finalDesc}"
${spreadsheetColumns && spreadsheetColumns.length > 0 ? `Колонки из исходной Excel-таблицы: ${JSON.stringify(spreadsheetColumns)}` : ""}
${spreadsheetRows && spreadsheetRows.length > 0 ? `Пример строк данных из исходной Excel-таблицы: ${JSON.stringify(spreadsheetRows.slice(0, 3))}` : ""}

Соблюдай официальную инструкцию по разработке приложений на Integram (integram-app-workflow-short.md):
- Создай правильные имена таблиц (lowercase, snake_case, e.g. clients, orders).
- Используй строго поддерживаемые Integram типы колонок: t=text (текст), t=num (число), t=date (дата), t=ref_{имя_таблицы} (ссылка на другую родительскую таблицу).
- Напиши правильные, полностью валидные структуры API-запросов (скрипт) с использованием idempotent эндпоинтов _d_new (создание полей и таблиц) и _d_req (запросы данных).
- Напиши красивый адаптивный HTML-шаблон рабочего места (на русском языке) с Tailwind классами, где поля ввода имеют имена t{column_id} для прямой привязки.
- Напиши JS-скрипт автоматизации с обработчиками событий, AJAX-запросами на /_d_req.
- Пропиши роли, маски прав доступа (WRITE, READ, ADMIN) и разделы меню в _menu.
- Сгенерируй тестовые доступы (не менее двух demo-пользователей: один администратор/руководитель с полными правами, один исполнитель/оператор) для демонстрации приложения. Каждый тестовый доступ должен содержать роль, логин (email), пароль и описание зоны ответственности.
- Создай JSON-данные для первоначального наполнения, обязательно включив туда наполнение системных таблиц прав доступа (_roles, _users, _menu) с созданными demo-пользователями, а также демонстрационные данные для бизнес-таблиц (клиенты, транзакции, задачи и т.д.).`;

      const workflowResponseSchema = {
        type: Type.OBJECT,
        properties: {
          step1_consolidation: {
            type: Type.OBJECT,
            properties: {
              businessDomain: { type: Type.STRING },
              userJourneys: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    role: { type: Type.STRING },
                    journey: { type: Type.STRING },
                    description: { type: Type.STRING }
                  },
                  required: ["role", "journey", "description"]
                }
              },
              requirementsChecklist: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            },
            required: ["businessDomain", "userJourneys", "requirementsChecklist"]
          },
          step2_schema: {
            type: Type.OBJECT,
            properties: {
              tables: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    name: { type: Type.STRING },
                    columns: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          id: { type: Type.STRING },
                          name: { type: Type.STRING },
                          format: { type: Type.STRING }
                        },
                        required: ["id", "name", "format"]
                      }
                    },
                    relations: { type: Type.STRING }
                  },
                  required: ["id", "name", "columns", "relations"]
                }
              }
            },
            required: ["tables"]
          },
          step3_script: {
            type: Type.OBJECT,
            properties: {
              payloadJson: { type: Type.STRING },
              scriptExplanation: { type: Type.STRING }
            },
            required: ["payloadJson", "scriptExplanation"]
          },
          step4_templates: {
            type: Type.OBJECT,
            properties: {
              htmlCode: { type: Type.STRING },
              jsCode: { type: Type.STRING },
              cssNotes: { type: Type.STRING }
            },
            required: ["htmlCode", "jsCode", "cssNotes"]
          },
          step5_roles_permissions: {
            type: Type.OBJECT,
            properties: {
              roles: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    mask: { type: Type.STRING },
                    tablesAccess: { type: Type.STRING }
                  },
                  required: ["name", "mask", "tablesAccess"]
                }
              },
              menuItems: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              demoUsers: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    role: { type: Type.STRING },
                    login: { type: Type.STRING },
                    password: { type: Type.STRING },
                    description: { type: Type.STRING }
                  },
                  required: ["role", "login", "password", "description"]
                }
              }
            },
            required: ["roles", "menuItems", "demoUsers"]
          },
          step6_seeding: {
            type: Type.OBJECT,
            properties: {
              seedPayload: { type: Type.STRING },
              instructions: { type: Type.STRING }
            },
            required: ["seedPayload", "instructions"]
          },
          step7_checklist: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: [
          "step1_consolidation",
          "step2_schema",
          "step3_script",
          "step4_templates",
          "step5_roles_permissions",
          "step6_seeding",
          "step7_checklist"
        ]
      };

      const { text, modelUsed } = await generateWithFallback(
        ai,
        ["gemini-3.5-flash", "gemini-3.1-flash-lite", "gemini-flash-latest"],
        promptText,
        {
          systemInstruction: "You are a professional low-code systems architect for the Integram platform. Your sole task is to generate beautiful, production-ready, fully detailed Russian workflow assets for an Integram Low-code app based on user inputs. You must return a single, valid, clean JSON object matching the exact structure of the response schema, with all codes written as escaped strings.",
          responseMimeType: "application/json",
          responseSchema: workflowResponseSchema
        }
      );

      if (!text) {
        throw new Error("Empty response received from Gemini.");
      }

      console.log(`[Integram Builder] Generation succeeded using model: ${modelUsed}`);
      let cleanText = text.trim();
      if (cleanText.startsWith("```")) {
        cleanText = cleanText.replace(/^```(?:json)?\n?/i, "").replace(/\n?```$/, "").trim();
      }
      const result = JSON.parse(cleanText);
      res.json(result);

    } catch (err: any) {
      console.error("[Integram Builder] Gemini generation error, falling back.", err);
      runFallback();
    }
  });

  // Integrate Vite for asset serving in dev, or static asset delivery in production
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://localhost:${PORT} in ${process.env.NODE_ENV || "development"} mode`);
  });
}

startServer().catch((err) => {
  console.error("Critical error starting server:", err);
});
